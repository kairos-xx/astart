"""Auto-annotated Python module."""

# autowrap's normalise-to-google pass currently strips structured
# ``Args:``/``Returns:`` blocks when the descriptions look like placeholders;
# keep it disabled so the templated docstrings emitted by ``add_doc_strings``
# survive intact and existing real docstrings are left alone too.
from __future__ import annotations

from abc import ABC, abstractmethod
from asyncio import Task, create_task, gather, sleep, wait_for
from asyncio import run as asyncio_run
from collections import Counter
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum, auto
from functools import lru_cache, reduce
from itertools import accumulate, chain, groupby, islice, takewhile
from json import dumps, loads
from pathlib import Path
from re import Match, Pattern, search, split, sub
from re import compile as re_compile
from re import match as re_match
from subprocess import CompletedProcess, run
from sys import stdout
from textwrap import dedent
from time import monotonic
from time import sleep as time_sleep
from typing import (
    TYPE_CHECKING,
    ClassVar,
    Concatenate,
    Final,
    NamedTuple,
    Protocol,
    Self,
    TextIO,
    TypedDict,
    TypeGuard,
    TypeVar,
    final,
    overload,
    override,
)

if TYPE_CHECKING:
    from collections.abc import (
        AsyncGenerator,
        AsyncIterator,
        Awaitable,
        Callable,
        Generator,
        Hashable,
        Iterable,
        Mapping,
        MutableMapping,
        Sequence,
        Sized,
    )
    from types import TracebackType


P = TypeVar(name="P")
Q = TypeVar(name="Q")
R = TypeVar(name="R")
S = TypeVar(name="S")
U = TypeVar(name="U")

type JSONPrimitive = str | int | float | bool | None
type StringList = list[str]
type _CoerceValueTree = dict[object, _CoerceValueTree | object]
type _DeepMergeTree = dict[object, _DeepMergeTree | object]
type _FlattenTreeTree = dict[str, _FlattenTreeTree | object]
type JSONValue = (
    str | int | float | bool | None | list[JSONValue] | dict[str, JSONValue]
)


@final
class Constants:
    int_18: Final[int] = 18
    int_5: Final[int] = 5
    int_neg_40: Final[int] = -40
    int_100: Final[int] = 100
    int_90: Final[int] = 90
    int_80: Final[int] = 80
    int_70: Final[int] = 70
    int_60: Final[int] = 60
    int_24: Final[int] = 24
    int_12: Final[int] = 12
    int_6: Final[int] = 6
    int_2: Final[int] = 2
    int_3: Final[int] = 3
    int_500: Final[int] = 500
    int_20: Final[int] = 20
    int_950: Final[int] = 950
    int_850: Final[int] = 850
    int_750: Final[int] = 750
    int_600: Final[int] = 600
    int_10000: Final[int] = 10000
    int_50000: Final[int] = 50000
    int_200000: Final[int] = 200000
    int_4: Final[int] = 4
    int_800: Final[int] = 800
    int_6800: Final[int] = 6800
    int_42800: Final[int] = 42800
    int_1024: Final[int] = 1024

    LONG_LITERAL: Final[str] = (
        "lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do "
        "eiusmod tempor incididunt ut labore et dolore magna aliqua, ut enim ad "
        "minim veniam"
    )
    GREETING: Final[str] = "module-level-string"
    fib_cache: Final[dict[int, int]] = {}
    title_cache: Final[dict[str, str]] = {}
    default_batch_size: Final[int] = 256
    known_tags: Final[list[str]] = ["alpha", "beta", "gamma"]
    priority_levels: Final[dict[str, int]] = {"low": 1, "medium": 5, "high": 9}
    channel_rgb: Final[tuple[int, int, int]] = (12, 34, 56)


def aprint(
    *args: object,
    sep: str | None = None,
    end: str | None = None,
    file: str | Path | TextIO | None = None,
    mode: str = "a",
    flush: bool = False,
) -> None:
    """Mimic print() using write(), optionally writing to a file path."""
    with (
        Path(file).open(mode=mode, encoding="utf-8")
        if isinstance(file, str | Path)
        else nullcontext(enter_result=file or stdout)
    ) as stream:
        _ = stream.write(
            (sep if sep is not None else " ").join(map(str, args))
            + (end if end is not None else "\n"),
        )
        if flush:
            _ = stream.flush()


# =============================================================================
# 1. Docstring style normalisation — four flavours of one function
# =============================================================================
# The normaliser should land all four below in Google style configured by the
# header ``# AUTOTYPE: docstrings-format=google``.


def google_style(
    names: Iterable[str],
    *,
    keep_empty: bool = False,
) -> StringList:
    """Summarise a sequence of names.

    Args:
        names (Iterable[str]): Sequence of raw names that may need whitespace cleanup and
            title casing.
        keep_empty (bool): Whether empty items should be preserved
            after normalization.

    Returns:
        Normalized names ready for display.

    Raises:
        ValueError: If all names are empty and keep_empty is False.

    """
    return [n.strip() for n in names if keep_empty or n.strip()]


def numpy_style(
    names: Iterable[str],
    *,
    keep_empty: bool = False,
) -> StringList:
    """Summarise a sequence of names.

    Args:
        names (Iterable[str]): Sequence of raw names that may need whitespace cleanup and
            title casing.
        keep_empty (bool): Whether empty items should be preserved
            after normalization.

    Returns:
        Normalized names ready for display.

    Raises:
        ValueError: If all names are empty and keep_empty is False.

    """
    return [n.strip() for n in names if keep_empty or n.strip()]


def rest_style(
    names: Iterable[str],
    *,
    keep_empty: bool = False,
) -> StringList:
    """Summarise a sequence of names.

    Args:
        names (Iterable[str]): Sequence of raw names that may need whitespace
        keep_empty (bool): Whether empty items should be preserved.

    Returns:
        Normalized names ready for display.

    Raises:
        ValueError: If all names are empty and keep_empty is False.

    """
    return [n.strip() for n in names if keep_empty or n.strip()]


def github_style(
    names: Iterable[str],
    *,
    keep_empty: bool = False,
) -> StringList:
    """Summarise a sequence of names.

    Args:
        names (Iterable[str]): Sequence of raw names that may need whitespace cleanup and
            title casing.
        keep_empty (bool): Whether empty items should be preserved.

    Returns:
        Normalized names ready for display.

    Raises:
        ValueError: If all names are empty and keep_empty is False.

    """
    return [n.strip() for n in names if keep_empty or n.strip()]


def missing_docstring_target(value: object, repeat: int = 2) -> str:
    """Return missing docstring target.

    Args:
        value (object): The value value passed to the call.
        repeat (int): The repeat value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return str(value) * repeat


# =============================================================================
# 2. Long single-line docstring → paragraph-wrapped
# =============================================================================


def long_single_line_doc(value: object) -> object:
    """This is a deliberately very long single-line summary that exceeds the.

    configured line width so the wrapper has to fold it across multiple
    physical lines while preserving the semantic punctuation and the
    trailing period at the end of the sentence.
    """
    return value


# =============================================================================
# 3. Bullet renest + nested-bullet indentation
# =============================================================================


def bullets_and_nesting() -> None:
    """Demonstrate bullet renesting and nested indentation.

    Top-level bullets that should align after wrapping:
    - primary item
      - nested item under primary (deeper indent should be
        preserved relative to the parent)
        - third-level nested item with a long description that
          forces a wrap of the body line
      - sibling nested item
    - second top-level item

    Mixed numbered + bullets:
    1. first numbered item
    2. second numbered item with intentionally extra space after
       the dot (separator-normaliser should collapse it)
    3. third item using a different separator (normaliser unifies)
    """
    return


# =============================================================================
# 4. Colon-aligned definitions and ruler underlines
# =============================================================================


def colon_aligned_and_rulers(a: float, b: float, c: float) -> float:
    """Show colon-introduced definition alignment and ruler-line tidy.

    Args:
        a (float): a short description that should align with siblings
        b (float): another one whose name is longer; the colon-alignment
            pass should pad ``a`` so its colon column matches.
        c (float): a third with a longer name still and a multi-line body
            wrapping the rest of the prose under the colon column.

    Attributes:
        items: underlined section heading where the ``----`` underline
            should be normalised to match the heading width exactly.

    Methods:
        run: another underlined section header.

    """
    return a + b + c


# =============================================================================
# 5. Code-block preservation, URL preservation, backtick names
# =============================================================================


def code_blocks_and_urls() -> None:
    """Preserve fenced code and URLs verbatim while wrapping prose.

    The wrapper should NOT touch the fenced block below,
    nor split URLs across lines. Inline backtick names like
    ``my_function`` should be preserved as visual emphasis.

    Example:
        result = my_function(value=42)
        print(result.upper())

    Reference:
        https://example.com/very/long/path/that/should/not/be/broken?query=1&also=2

    """
    return


# =============================================================================
# 6. Continuation paragraphs under list items
# =============================================================================


def continuation_paragraphs() -> None:
    """List items with continuation prose.

    Notes:
        - The first item has a one-line body.

          A continuation paragraph belonging to the same list item,
          indented under the bullet, should remain associated with the
          item after wrapping.

        - Second item.

          Another continuation paragraph that should wrap independently
          from the first item's prose, preserving the blank line.

    """
    return


# =============================================================================
# 7. Multi-line consecutive comment wrapping
# =============================================================================
# This is a deliberately long block comment that spans many lines and
# would, without the comment wrapper, leave a stretched physical line.
# The wrapper should fold all these consecutive lines into a single re-
# flowed paragraph with the leading ``#`` preserved on every emitted
# line so the visual effect is consistent. A separate paragraph below
# the blank line should NOT be merged into the one above because the
# wrapper respects blank-line boundaries.


# =============================================================================
# 8. Long string assignments → parenthesised implicit concatenation
# =============================================================================
# =============================================================================
# 9. Inference feature 1 — SSA local re-typing
# =============================================================================


def union_via_reassignment(*, flag: bool) -> int | str:
    """Return union via reassignment.

    Args:
        flag (bool): The flag value passed to the call.

    Returns:
        The computed value of type ``int | str``.

    """
    probe: int | str = 0
    if flag:
        probe = "fallback"
    return probe


# =============================================================================
# 10. Inference feature 2 — `is None` / `is not None` narrowing
# =============================================================================


def narrow_via_is_none(value: Sized | None) -> int:
    """Return narrow via is none.

    Args:
        value (Sized | None): The value value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    if value is None:
        return 0
    return len(value) * 2


# =============================================================================
# 11. Inference feature 3 — receiver chain inference
# =============================================================================


def chain_inference(p: str) -> tuple[str, list[str]]:
    """Return chain inference.

    Args:
        p (str): The p value passed to the call.

    Returns:
        The computed value of type ``tuple[str, list[str]]``.

    """
    body: str = Path(p).read_text()
    lines: list[str] = body.splitlines()
    upper_first: str = lines[0].upper() if lines else ""
    raw: bytes = Path(p).read_bytes()
    text: str = raw.decode()
    return upper_first, text.split()


# =============================================================================
# 12. Inference feature 4 — kwarg backflow at call sites
# =============================================================================


def helper_backflow(name: str, count: int, prefix: str) -> str:
    """Return helper backflow.

    Args:
        name (str): The name value passed to the call.
        count (int): The count value passed to the call.
        prefix (str): The prefix value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return f"{prefix}{name}:{count}"


def caller_with_kwargs() -> str:
    """Return caller with kwargs.

    Returns:
        The computed value of type ``str``.

    """
    return helper_backflow(name="alice", count=42, prefix=">> ")


# =============================================================================
# 13. Inference feature 5 — Literal narrowing from `==` / `match`
# =============================================================================


def colour_to_hex(colour: str) -> str:
    """Return colour to hex.

    Args:
        colour (str): The colour value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if colour == "red":
        return "#ff0000"
    if colour == "green":
        return "#00ff00"
    if colour == "blue":
        return "#0000ff"
    return "#000000"


def http_status_word(code: object) -> str | None:
    """Return http status word.

    Args:
        code (object): The code value passed to the call.

    Returns:
        The computed value of type ``str | None``.

    """
    match code:
        case 200:
            return "ok"
        case 404:
            return "missing"
        case 500:
            return "error"
        case _:
            return "unknown"


# =============================================================================
# 14. Inference feature 6 — TypedDict synthesis
# =============================================================================


def build_user_record(name: str, age: int) -> dict[str, int | str | bool]:
    """Return build user record.

    Args:
        name (str): The name value passed to the call.
        age (int): The age value passed to the call.

    Returns:
        The computed value of type ``dict[str, int | str | bool]``.

    """
    if not name:
        return {"name": "anonymous", "age": 0, "active": False}
    if age < Constants.int_18:
        return {"name": name, "age": age, "active": False}
    return {"name": name, "age": age, "active": True}


# =============================================================================
# 15. autokwargs — deep inspection of stdlib + workspace receivers
# =============================================================================
# - ``f.write_text("hi", encoding="utf-8")`` becomes ``data="hi"`` -
# ``c.most_common(2)`` becomes ``n=2``


def writes_path(target_dir: str) -> str:
    """Return writes path.

    Args:
        target_dir (str): The target dir value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    f: Path = Path(target_dir) / "out.txt"
    _ = f.write_text(data="hello world", encoding="utf-8")
    return f.read_text()


def top_words(text: str, n: int) -> list[tuple[str, int]]:
    """Return top words.

    Args:
        text (str): The text value passed to the call.
        n (int): The n value passed to the call.

    Returns:
        The computed value of type ``list[tuple[str, int]]``.

    """
    c: Counter[str] = Counter(text.split())
    return c.most_common(n=n)


# =============================================================================
# 16. Autosort — methods out of canonical order
# =============================================================================


class OutOfOrderClass:
    """Methods intentionally misordered to exercise autosort."""

    def __init__(self, x: object) -> None:
        """Return init.

        Args:
            x (object): The x value passed to the call.

        """
        self._x: object = x

    @override
    def __repr__(self) -> str:
        """Return repr."""
        return f"OutOfOrderClass({self._x!r})"

    @property
    def value(self) -> object:
        """Return value.

        Returns:
            The computed value of type ``object``.

        """
        return self._x

    @classmethod
    def from_int(cls, value: object) -> Self:
        """Return from int.

        Args:
            value (object): The value value passed to the call.

        Returns:
            The computed value of type ``Self``.

        """
        return cls(value)

    @staticmethod
    def banner() -> str:
        """Return banner.

        Returns:
            The computed value of type ``str``.

        """
        return "OutOfOrderClass"

    def helper(self) -> object:
        """Return helper.

        Returns:
            The computed value of type ``object``.

        """
        return self._x


# =============================================================================
# 17. autorestore — lint-ignore positions survive transformation
# =============================================================================
# Each suppression below is on a line that the pipeline will rewrap;
# autorestore should reposition the comment onto the new line where the
# diagnostic still fires.


async def with_timeout(
    coro: Awaitable[object],
    timeout: float | None,  # noqa: ASYNC109
) -> object | None:
    """Run coro with a timeout; return None on expiry."""
    try:
        return await wait_for(fut=coro, timeout=timeout)
    except TimeoutError:
        return None


def narrow_with_assert(x: float) -> float:
    """Use assert isinstance to narrow x to numeric."""
    assert isinstance(x, (int, float))  # noqa: S101
    return x + 1


@contextmanager
def timer(label: object) -> Generator[None]:
    """Print elapsed time around a ``with`` block."""
    start: object = monotonic()
    try:
        yield
    finally:
        elapsed: float = monotonic() - start
        aprint(f"{label}: {elapsed:.4f}s")


def yield_in_loop(n: int) -> Generator[int]:
    """Yield-in-for that ruff would suggest converting to yield-from."""
    for i in range(n):  # noqa: UP028
        yield i


# =============================================================================
# 18. Generators + async generator + Protocol + NamedTuple + TypedDict
# =============================================================================


def count_up(n: int) -> Generator[int]:
    """Yield integers from 0 up to n-1."""
    yield from range(n)


async def async_count(n: int) -> AsyncGenerator[int]:
    """Async generator yielding integers."""
    for i in range(n):
        yield i


@dataclass(frozen=True)
class Vector3:
    """Immutable 3-D vector."""

    x: float
    y: float
    z: float = 0.0

    def dot(self, other: Vector3) -> float:
        """Return dot.

        Args:
            other (Vector3): The other value passed to the call.

        Returns:
            The computed value of type ``float``.

        """
        return self.x * other.x + self.y * other.y + self.z * other.z


@dataclass
class Stack[T]:
    """Stack backed by a list."""

    items: list[T] = field(default_factory=list)

    def pop(self) -> T | None:
        """Return pop.

        Returns:
            The computed value of type ``T | None``.

        """
        return self.items.pop() if self.items else None

    def push(self, item: T) -> None:
        """Return push.

        Args:
            item (T): The item value passed to the call.

        """
        _ = self.items.append(item)


class Sizeable(Protocol):
    """Anything with __len__."""

    def __len__(self) -> int:
        """Return the container length."""
        ...


class Point(NamedTuple):
    """2-D point."""

    x: float
    y: float


class WorkerConfig(TypedDict):
    """Statically-shaped dict input."""

    name: str
    parallelism: int


# =============================================================================
# 19. Walrus, comprehensions, match-mapping
# =============================================================================


def first_long_token(text: str) -> str | None:
    """Return first long token.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``str | None``.

    """
    return next((t for t in text.split() if len(t) > Constants.int_5), None)


def keep_unique[T](items: Iterable[T]) -> list[T]:
    """Return keep unique.

    Args:
        items (Iterable[T]): The items value passed to the call.

    Returns:
        The computed value of type ``list[T]``.

    """
    seen: set[T] = set()
    return [x for x in items if not (x in seen or seen.add(x))]


def describe_action(payload: dict[str, JSONValue]) -> str | None:
    """Return describe action.

    Args:
        payload (dict[str, JSONValue]): The payload value passed to the call.

    Returns:
        The computed value of type ``str | None``.

    """
    match payload:
        case {"kind": "move", "dx": dx, "dy": dy}:
            return f"move by ({dx},{dy})"
        case {"kind": "stop"}:
            return "stop"
        case _:
            return "ignore"


# =============================================================================
# 20. Self-returning methods → Self
# =============================================================================


class Builder:
    """Fluent builder; each setter returns self."""

    def __init__(self) -> None:
        """Return init."""
        self._parts: list[object] = []

    def add(self, x: object) -> Self:
        """Return add.

        Args:
            x (object): The x value passed to the call.

        Returns:
            The computed value of type ``Self``.

        """
        _ = self._parts.append(x)
        return self

    def build(self) -> str:
        """Return build.

        Returns:
            The computed value of type ``str``.

        """
        return ":".join(map(str, self._parts))


# =============================================================================
# 22. Deeply nested bullet alignment + Returns with multiple typed entries
# =============================================================================


def deeply_nested_bullets() -> tuple[int, list[object], dict[object, object]]:
    """Showcase deep bullet renest, alignment, and structured Returns.

    Notes:
        * top-level star bullet (should be normalised to ``-``):
          * level-2 star bullet with a long body that has to fold across
            several physical lines while staying aligned
            * level-3 nested bullet whose marker indent should be
              preserved exactly two columns deeper than its parent
            * level-3 sibling
          * level-2 sibling with mixed inline ``code`` and a URL
            https://example.com/extremely/long/path/that/must/not/break
        1. numbered top-level item
           a. lettered nested item under numeric (mixed-marker nesting)
           b. lettered sibling
              i. roman-numeral inner item
              ii. roman-numeral sibling
        2. numbered sibling

    Args:
        first: a short name to align against
        second_much_longer_name: longer sibling whose colon
            column should anchor the alignment for both items
        third: a third item with a multi-line description that should
            re-wrap under the colon column without disturbing the bullets below.

    Returns:
        tuple: A 3-tuple containing
            - ``int``: the count of top-level items
            - ``list[str]``: the flattened bullet bodies in DFS order
            - ``dict[str, int]``: per-marker-style frequency map

    Raises:
        ValueError: never, but documented to exercise the
            Raises section alignment and multi-line body wrapping.

    """
    return 0, [], {}


# =============================================================================
# 23. Inference through imported non-builtin (stdlib) modules
# =============================================================================
# Exercises receiver-chain inference across ``json``, ``re``, ``subprocess``
# and Path so autotype/autokwargs trace return types through module APIs.


def parse_user_json(blob: str) -> tuple[object | None, object | None]:
    """Return parse user json.

    Args:
        blob (str): The blob value passed to the call.

    Returns:
        The computed value of type ``tuple[object | None, object | None]``.

    """
    data: dict[str, object] = loads(s=blob)
    name: object | None = data.get("name")
    age: object | None = data.get("age", 0)
    return name, age


def extract_first_int(text: str) -> int | None:
    """Return extract first int.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``int | None``.

    """
    match: Match[str] | None = search(pattern=r"\d+", string=text)
    if match is None:
        return None
    return int(match.group(0))


def normalise_whitespace(text: str) -> str:
    """Return normalise whitespace.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    pattern: Pattern[str] = re_compile(pattern=r"\s+")
    return pattern.sub(repl=" ", string=text).strip()


def list_python_versions() -> tuple[str, int]:
    """Return list python versions.

    Returns:
        The computed value of type ``tuple[str, int]``.

    """
    proc: CompletedProcess[str] = run(
        args=["python3", "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    return proc.stdout.strip(), proc.returncode


# =============================================================================
# 24. Conflicting / shadowed scopes — same name, different inferred types
# =============================================================================
# The inference engine must keep per-scope bindings distinct so the outer
# ``value: str`` is not confused with the inner ``value: int``.


def length_doubled(text: str) -> int:
    """Return length doubled.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    doubled: int = len(text) * 2
    return doubled


def coerce_in_branches(*, flag: bool, raw: str) -> float | str:
    """Return coerce in branches.

    Args:
        flag (bool): The flag value passed to the call.
        raw (str): The raw value passed to the call.

    Returns:
        The computed value of type ``float | str``.

    """
    if flag:
        coerced: float | str = float(raw)
    else:
        coerced = str(raw).upper()
    return coerced


class ScopeMixer:
    """Class attribute and method-local exercise distinct scopes."""

    counter: int = 0

    def bump(self, delta: int) -> int:
        """Return bump.

        Args:
            delta (int): The delta value passed to the call.

        Returns:
            The computed value of type ``int``.

        """
        next_value: int = self.counter + delta
        self.counter = next_value
        return next_value

    def reset(self) -> int:
        """Return reset.

        Returns:
            The computed value of type ``int``.

        """
        self.counter = 0
        return self.counter


# =============================================================================
# 25. Magic-number injection — many int/float literals in expressions
# =============================================================================
# autoinsert should hoist these into named module-level constants.


def temperature_score(celsius: float) -> float:
    """Return temperature score.

    Args:
        celsius (float): The celsius value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if celsius < Constants.int_neg_40:
        return 0.0
    if celsius < 0:
        return celsius * 0.5 + 50
    if celsius < Constants.int_100:
        return celsius * 1.5 + 75
    return 300.0


def grade_from_score(score: int) -> str:
    """Return grade from score.

    Args:
        score (int): The score value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if score >= Constants.int_90:
        return "A"
    if score >= Constants.int_80:
        return "B"
    if score >= Constants.int_70:
        return "C"
    if score >= Constants.int_60:
        return "D"
    return "F"


def compute_discount(price: float, units: int) -> float:
    """Return compute discount.

    Args:
        price (float): The price value passed to the call.
        units (int): The units value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if units >= Constants.int_24:
        return price * 0.65
    if units >= Constants.int_12:
        return price * 0.8
    if units >= Constants.int_6:
        return price * 0.9
    return price


# =============================================================================
# 26. autokwargs — positional calls promoted to keyword on stdlib + workspace
# =============================================================================


def write_log_file(target_dir: str, payload: object) -> Path:
    """Return write log file.

    Args:
        target_dir (str): The target dir value passed to the call.
        payload (object): The payload value passed to the call.

    Returns:
        The computed value of type ``Path``.

    """
    path: Path = Path(target_dir) / "log.json"
    _ = path.write_text(data=dumps(obj=payload, indent=2), encoding="utf-8")
    return path


def replace_tokens(text: str, token: str, replacement: str) -> str:
    """Return replace tokens.

    Args:
        text (str): The text value passed to the call.
        token (str): The token value passed to the call.
        replacement (str): The replacement value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return sub(pattern=token, repl=replacement, string=text, count=0)


def slice_window[T](
    items: Iterable[T],
    start: int,
    stop: int,
) -> list[T]:
    """Return slice window.

    Args:
        items (Iterable[T]): The items value passed to the call.
        start (int): The start value passed to the call.
        stop (int): The stop value passed to the call.

    Returns:
        The computed value of type ``list[T]``.

    """
    return list(items)[start:stop]


# =============================================================================
# 27. Fuller method-order exercise (canonical: dunders → classmethod →
# staticmethod → property → public → private)
# =============================================================================


class OrderingHeavy:
    """A class with members in deliberately scrambled order."""

    def __init__(self, items: list[int]) -> None:
        """Return init.

        Args:
            items (list[int]): The items value passed to the call.

        """
        self._items: list[int] = list(items)

    def __len__(self) -> int:
        """Return len."""
        return len(self._items)

    @override
    def __repr__(self) -> str:
        """Return repr."""
        return f"OrderingHeavy(items={self._items!r})"

    @property
    def size(self) -> int:
        """Return size.

        Returns:
            The computed value of type ``int``.

        """
        return len(self._items)

    @classmethod
    def make_empty(cls) -> Self:
        """Return make empty.

        Returns:
            The computed value of type ``Self``.

        """
        return cls([])

    @staticmethod
    def banner() -> str:
        """Return banner.

        Returns:
            The computed value of type ``str``.

        """
        return "OrderingHeavy"

    def public_action(self) -> int:
        """Return public action.

        Returns:
            The computed value of type ``int``.

        """
        return self._helper(x=self.size)

    def _helper(self, x: int) -> int:
        """Return helper."""
        return x * 2


# =============================================================================
# 28. @overload — multiple signatures + runtime dispatch
# =============================================================================


@overload
def coerce(value: int) -> str: ...
@overload
def coerce(value: str) -> int: ...
def coerce(value: int | str) -> int | str:
    """Return coerce.

    Args:
        value (int | str): The value value passed to the call.

    Returns:
        The computed value of type ``int | str``.

    """
    if isinstance(value, int):
        return str(value)
    return len(value)


# =============================================================================
# 28b. functools.lru_cache — decorator preserving recursive signature
# =============================================================================


@lru_cache(maxsize=128)
def fib(n: int) -> int:
    """Return fib.

    Args:
        n (int): The n value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    return n if n < Constants.int_2 else fib(n=n - 1) + fib(n=n - 2)


# =============================================================================
# 30. Enum values + Literal narrowing on members
# =============================================================================


class Status(Enum):
    """Three-state job status."""

    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"


def status_priority(status: Status) -> int:
    """Return status priority.

    Args:
        status (Status): The status value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    if status is Status.PENDING:
        return 0
    if status is Status.RUNNING:
        return 1
    return 2


# =============================================================================
# 31. Dataclass field with default_factory + __post_init__
# =============================================================================


@dataclass
class HistoryBuffer:
    """Bounded history buffer with derived count attribute."""

    items: list[str] = field(default_factory=list)
    capacity: int = 16

    def __post_init__(self) -> None:
        """Return post init."""
        if len(self.items) > self.capacity:
            self.items = self.items[-self.capacity :]
        self.count: int = len(self.items)


# =============================================================================
# 32. ClassVar — class-scoped constants distinct from instance attrs
# =============================================================================


class HttpClient:
    """Demonstrate ClassVar distinct from instance attrs."""

    DEFAULT_TIMEOUT: ClassVar[float] = 30.0
    PROTOCOL: ClassVar[str] = "https"

    def __init__(self, host: str, timeout: float | None = None) -> None:
        """Return init.

        Args:
            host (str): The host value passed to the call.
            timeout (float | None): The timeout value passed to the call.

        """
        self.host: str = host
        self.timeout: float | None = (
            timeout if timeout is not None else self.DEFAULT_TIMEOUT
        )


# =============================================================================
# 33. Walrus operator inside conditional and comprehension
# =============================================================================


def walrus_filter(items: list[str]) -> list[str]:
    """Return walrus filter.

    Args:
        items (list[str]): The items value passed to the call.

    Returns:
        The computed value of type ``list[str]``.

    """
    return [stripped for x in items if (stripped := x.strip())]


def walrus_in_if(items: list[str]) -> int | None:
    """Return walrus in if.

    Args:
        items (list[str]): The items value passed to the call.

    Returns:
        The computed value of type ``int | None``.

    """
    if (n := len(items)) > Constants.int_3:
        return n
    return None


# =============================================================================
# 34. f-string with nested expressions and format spec
# =============================================================================


def format_record(name: str, score: float, width: int) -> str:
    """Return format record.

    Args:
        name (str): The name value passed to the call.
        score (float): The score value passed to the call.
        width (int): The width value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    upper: str = name.upper()
    return f"{upper:>{width}} :: {score:7.2f}% [{Status.DONE.value!r}]"


# =============================================================================
# 35. Async context manager + async iteration
# =============================================================================


class AsyncGate:
    """Simple async context manager + async iterator."""

    def __init__(self, limit: int) -> None:
        """Return init.

        Args:
            limit (int): The limit value passed to the call.

        """
        self._limit: int = limit
        self._n: int = 0

    async def __aenter__(self) -> Self:
        """Return aenter."""
        return self

    async def __aexit__(self, *exc: object) -> None:
        """Return aexit."""
        self._n = 0

    def __aiter__(self) -> AsyncGate:
        """Return aiter."""
        return self

    async def __anext__(self) -> int:
        """Return anext."""
        if self._n >= self._limit:
            raise StopAsyncIteration
        self._n += 1
        return self._n


async def consume_gate(limit: int) -> list[int]:
    """Return consume gate.

    Args:
        limit (int): The limit value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    out: list[int] = []
    async with AsyncGate(limit=limit) as gate:
        async for value in gate:
            _ = out.append(value)
    return out


# =============================================================================
# 36. Starred unpacking and **kwargs forwarding
# =============================================================================


def forward_call[**P, R](
    target: Callable[P, R],
    *args: P.args,
    **kwargs: P.kwargs,
) -> R:
    """Return forward call.

    Args:
        target (Callable[P, R]): The target value passed to the call.
        *args (P.args): The args value passed to the call.
        **kwargs (P.kwargs): The kwargs value passed to the call.

    Returns:
        The computed value of type ``R``.

    """
    return target(*args, **kwargs)


def merge_dicts(
    base: dict[str, object],
    extras: dict[str, object],
) -> dict[str, object]:
    """Return merge dicts.

    Args:
        base (dict[str, object]): The base value passed to the call.
        extras (dict[str, object]): The extras value passed to the call.

    Returns:
        The computed value of type ``dict[str, object]``.

    """
    return {**base, **extras}


# =============================================================================
# 37. Iterator protocol — __iter__ + __next__
# =============================================================================


class CountDown:
    """Manual iterator that counts down from ``start`` to zero."""

    def __init__(self, start: int) -> None:
        """Return init.

        Args:
            start (int): The start value passed to the call.

        """
        self._current: int = start

    def __iter__(self) -> CountDown:
        """Return iter."""
        return self

    def __next__(self) -> int:
        """Return next."""
        if self._current <= 0:
            raise StopIteration
        self._current -= 1
        return self._current + 1


# =============================================================================
# 38. TypeGuard narrowing
# =============================================================================


def is_str_list(items: list[object]) -> TypeGuard[list[str]]:
    """Return is str list.

    Args:
        items (list[object]): The items value passed to the call.

    Returns:
        The computed value of type ``TypeGuard[list[str]]``.

    """
    return all(isinstance(x, str) for x in items)


def join_if_strings(items: list[object]) -> str:
    """Return join if strings.

    Args:
        items (list[object]): The items value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if is_str_list(items=items):
        return ", ".join(items)
    return ""


# =============================================================================
# 39. Forward inference — narrow as we walk down through guards
# =============================================================================
# Each assignment refines the inferred type further. autotype should
# track: raw: object → str (after isinstance) → str (split-result
# is list[str]) first: str → int (after int() coercion) ratio: float (from
# int / float arithmetic with explicit float divisor)


def forward_narrow_pipeline(raw: str) -> tuple[list[str], int, float]:
    """Return forward narrow pipeline.

    Args:
        raw (str): The raw value passed to the call.

    Returns:
        The computed value of type ``tuple[list[str], int, float]``.

    """
    assert isinstance(raw, str)  # noqa: S101
    parts: list[str] = raw.split(sep=":")
    first: int | str = parts[0]
    first = int(first)
    ratio: float = first / 3.5
    return parts, first, ratio


# =============================================================================
# 40. Backward inference — call-site usage refines the parameter type
# =============================================================================
# ``packet_payload`` and ``packet_count`` are only ever called with concrete
# types; autotype's kwarg-backflow should annotate them precisely from the
# call sites below without any explicit annotations at the def-site.


def packet_payload(name: str, headers: Sized, body: Sized) -> str:
    """Return packet payload.

    Args:
        name (str): The name value passed to the call.
        headers (Sized): The headers value passed to the call.
        body (Sized): The body value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return f"{name}:{len(headers)}:{len(body)}"


def packet_count(items: Iterable[object]) -> int:
    """Return packet count.

    Args:
        items (Iterable[object]): The items value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    return sum(1 for _ in items)


def call_packet_helpers() -> tuple[str, int]:
    """Return call packet helpers.

    Returns:
        The computed value of type ``tuple[str, int]``.

    """
    out: str = packet_payload(
        name="alpha",
        headers={"x-trace": "id-7"},
        body=b"hello",
    )
    return out, packet_count(items=["a", "b", "c"])


# =============================================================================
# 41. Deep docstring bullets — 4-level nesting + mixed marker styles
# =============================================================================


def deep_docstring_alignment() -> None:
    """Showcase 4-level bullet nesting with mixed marker styles.

    Layers (each level indents two columns deeper than its parent):

    - ``level 1`` — top-level dash item with a description long enough
      that the wrapper must fold it across multiple physical lines
      while keeping the continuation aligned under the first letter.
      * ``level 2`` — switches to star marker (renormalised to
        dash by the docstring normaliser) with body text that
        itself wraps to verify the continuation indent.
        + ``level 3`` — plus marker (also renormalised) with
          a multi-paragraph body:
          A continuation paragraph still belonging to ``level 3`` that must
          remain associated with the bullet after the blank-line separator above.
          - ``level 4`` — back to dash marker; the deepest
            level has a body wide enough to force a wrap and
            exercise the deepest column alignment.
          - ``level 4`` sibling whose colon-introduced body
            must align with the sibling above.

    Numbered nesting (markers and alignment also normalised):

    1. ``primary`` — top-level numbered.
       a) ``letter`` — lower-case letter marker with parenthesis
          separator (normaliser unifies to a single style).
          i. ``roman`` — lower-case roman inside a letter inside
             a numeric: three levels of mixed-marker nesting.
          ii. ``roman`` sibling with a body long enough to wrap
             under the column established by the marker.
       b) ``letter`` sibling.
    2. ``secondary`` — top-level sibling with one nested item:
       a) ``solo``.
    3. ``tertiary``.

    Description list (term : definition) — colon-introduced
    definitions that align on the longest term:

    short_term         : a brief description aligned to the
                         colon column established by the longest term below.
    medium_term        : another description; same alignment column.
    very_long_term_name: anchors the colon column for the group;
                         siblings above pad with spaces so all colons
                         stack vertically.

    Returns:
        None: this function exists purely to drive the wrapper.

    """
    return


# =============================================================================
# 42. Generic TypeVar containers — element type flows through methods
# =============================================================================
# Exercises PEP 695 syntax-style generics resolved by autotype: ``Stack[T]``
# preserves the element type across ``push``/``pop``/``peek``.


class TypedStack[T]:
    """Stack parameterised on element type ``T``."""

    def __init__(self) -> None:
        """Return init."""
        self._items: list[T] = []

    def __len__(self) -> int:
        """Return len."""
        return len(self._items)

    def peek(self) -> T | None:
        """Return peek.

        Returns:
            The computed value of type ``T | None``.

        """
        return self._items[-1] if self._items else None

    def pop(self) -> T | None:
        """Return pop.

        Returns:
            The computed value of type ``T | None``.

        """
        return self._items.pop() if self._items else None

    def push(self, item: T) -> None:
        """Return push.

        Args:
            item (T): The item value passed to the call.

        """
        _ = self._items.append(item)


class TypedQueue[T]:
    """FIFO queue parameterised on element type ``T``."""

    def __init__(self, items: list[T] | None = None) -> None:
        """Return init.

        Args:
            items (list[T] | None): The items value passed to the call.

        """
        self._items: list[T] = list(items) if items is not None else []

    def dequeue(self) -> T | None:
        """Return dequeue.

        Returns:
            The computed value of type ``T | None``.

        """
        return self._items.pop(0) if self._items else None

    def drain(self) -> list[T]:
        """Return drain.

        Returns:
            The computed value of type ``list[T]``.

        """
        drained: list[T] = list(self._items)
        _ = self._items.clear()
        return drained

    def enqueue(self, item: T) -> None:
        """Return enqueue.

        Args:
            item (T): The item value passed to the call.

        """
        _ = self._items.append(item)


class Pair[K, V]:
    """Two-key generic record mirroring ``typing.Generic`` style."""

    def __init__(self, key: K, value: V) -> None:
        """Return init.

        Args:
            key (K): The key value passed to the call.
            value (V): The value value passed to the call.

        """
        self.key: K = key
        self.value: V = value

    def swapped(self) -> Pair[V, K]:
        """Return swapped.

        Returns:
            The computed value of type ``Pair[V, K]``.

        """
        return Pair(key=self.value, value=self.key)


# =============================================================================
# 43. Abstract base class + concrete subclasses (template method)
# =============================================================================


class Renderer(ABC):
    """Abstract renderer with a templated public ``render`` method."""

    def render(self, value: object) -> str:
        """Return render.

        Args:
            value (object): The value value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        prepared: str = self._prepare(value=value)
        body: str = self._format(prepared=prepared)
        return self._wrap(body=body)

    @abstractmethod
    def _format(self, prepared: str) -> str:
        """Return ``prepared`` formatted for the concrete output."""

    def _prepare(self, value: object) -> str:
        """Return prepare."""
        return str(value).strip()

    def _wrap(self, body: str) -> str:
        """Return wrap."""
        return body


class JsonRenderer(Renderer):
    """Renderer that emits JSON-quoted strings."""

    @override
    def _format(self, prepared: str) -> str:
        """Return format."""
        return dumps(obj=prepared)


class BracketRenderer(Renderer):
    """Renderer that wraps the body in square brackets."""

    @override
    def _format(self, prepared: str) -> str:
        """Return format."""
        return prepared.upper()

    @override
    def _wrap(self, body: str) -> str:
        """Return wrap."""
        return f"[{body}]"


# =============================================================================
# 44. Mixin pattern — cooperative MRO, super() forwarding
# =============================================================================


class TimestampMixin:
    """Mixin attaching a creation timestamp to any record."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        """Return init.

        Args:
            *args (object): The args value passed to the call.
            **kwargs (object): The kwargs value passed to the call.

        """
        _ = super().__init__(*args, **kwargs)
        self.created_at: float = monotonic()


class CountingMixin:
    """Mixin counting how many times ``record`` has been called."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        """Return init.

        Args:
            *args (object): The args value passed to the call.
            **kwargs (object): The kwargs value passed to the call.

        """
        _ = super().__init__(*args, **kwargs)
        self.hits: int = 0

    def record(self) -> int:
        """Return record.

        Returns:
            The computed value of type ``int``.

        """
        self.hits += 1
        return self.hits


class AuditLog(TimestampMixin, CountingMixin):
    """Concrete record combining timestamp + counter mixins."""

    @override
    def __init__(self, source: str) -> None:
        """Return init.

        Args:
            source (str): The source value passed to the call.

        """
        _ = super().__init__()
        self.source: str = source

    def describe(self) -> str:
        """Return describe.

        Returns:
            The computed value of type ``str``.

        """
        return f"{self.source}@{self.created_at:.3f}#{self.hits}"


# =============================================================================
# 45. itertools / functools heavy use — receiver chains across stdlib
# =============================================================================


def running_total(values: list[int]) -> list[int]:
    """Return running total.

    Args:
        values (list[int]): The values value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    return list(accumulate(iterable=values))


def grouped_runs(text: str) -> list[tuple[str, int]]:
    """Return grouped runs.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``list[tuple[str, int]]``.

    """
    return [
        (key, sum(1 for _ in group)) for key, group in groupby(iterable=text)
    ]


def flatten_pairs(pairs: list[tuple[int, int]]) -> list[int]:
    """Return flatten pairs.

    Args:
        pairs (list[tuple[int, int]]): The pairs value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    return list(chain.from_iterable(pairs))


def first_n_under_limit(values: list[int], limit: int) -> list[int]:
    """Return first n under limit.

    Args:
        values (list[int]): The values value passed to the call.
        limit (int): The limit value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    return list(islice(takewhile(lambda v: v < limit, values), 8))


def fold_product(values: list[int]) -> int:
    """Return fold product.

    Args:
        values (list[int]): The values value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    return reduce(lambda a, b: a * b, values, 1)


# =============================================================================
# 46. datetime arithmetic — chain through stdlib date/time types
# =============================================================================


def now_iso() -> str:
    """Return now iso.

    Returns:
        The computed value of type ``str``.

    """
    return datetime.now(tz=UTC).isoformat()


def shift_days(stamp: datetime, days: int) -> datetime:
    """Return shift days.

    Args:
        stamp (datetime): The stamp value passed to the call.
        days (int): The days value passed to the call.

    Returns:
        The computed value of type ``datetime``.

    """
    return stamp + timedelta(days=days)


def is_recent(stamp: datetime, window_hours: int) -> bool:
    """Return is recent.

    Args:
        stamp (datetime): The stamp value passed to the call.
        window_hours (int): The window hours value passed to the call.

    Returns:
        The computed value of type ``bool``.

    """
    threshold: datetime = datetime.now(tz=UTC) - timedelta(hours=window_hours)
    return stamp >= threshold


def days_between(a: datetime, b: datetime) -> int:
    """Return days between.

    Args:
        a (datetime): The a value passed to the call.
        b (datetime): The b value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    return abs((a - b).days)


# =============================================================================
# 47. pathlib — heavy receiver-chain inference + with statements
# =============================================================================


def read_first_nonblank(path: Path) -> str:
    """Return read first nonblank.

    Args:
        path (Path): The path value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            return line.strip()
    return ""


def write_listing(target_dir: Path, names: list[str]) -> Path:
    """Return write listing.

    Args:
        target_dir (Path): The target dir value passed to the call.
        names (list[str]): The names value passed to the call.

    Returns:
        The computed value of type ``Path``.

    """
    listing: Path = target_dir / "listing.txt"
    _ = listing.parent.mkdir(parents=True, exist_ok=True)
    _ = listing.write_text(data="\n".join(sorted(names)), encoding="utf-8")
    return listing


def walk_python_files(root: Path) -> list[Path]:
    """Return walk python files.

    Args:
        root (Path): The root value passed to the call.

    Returns:
        The computed value of type ``list[Path]``.

    """
    return [
        p for p in root.rglob(pattern="*.py") if not p.name.startswith(".")
    ]


def file_size_kb(path: Path) -> float:
    """Return file size kb.

    Args:
        path (Path): The path value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    return path.stat().st_size / Constants.int_1024


# =============================================================================
# 48. collections.abc — ABC-based duck typing
# =============================================================================


def map_values[K, V, W](
    source: Mapping[K, V],
    fn: Callable[[V], W],
) -> dict[K, W]:
    """Return map values.

    Args:
        source (Mapping[K, V]): The source value passed to the call.
        fn (Callable[[V], W]): The fn value passed to the call.

    Returns:
        The computed value of type ``dict[K, W]``.

    """
    return {k: fn(v) for k, v in source.items()}


def merge_dicts_inplace(
    target: MutableMapping[str, int],
    extra: Mapping[str, int],
) -> None:
    """Return merge dicts inplace.

    Args:
        target (MutableMapping[str, int]): The target value passed to the call.
        extra (Mapping[str, int]): The extra value passed to the call.

    """
    for key, value in extra.items():
        target[key] = target.get(key, 0) + value


def iterable_to_counts(items: Iterable[str]) -> dict[str, int]:
    """Return iterable to counts.

    Args:
        items (Iterable[str]): The items value passed to the call.

    Returns:
        The computed value of type ``dict[str, int]``.

    """
    counts: dict[str, int] = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return counts


# =============================================================================
# 49. Recursive shape inference — tree walker that returns dict[str, object]
# =============================================================================


def flatten_tree(
    node: dict[str, JSONValue],
    prefix: str = "",
) -> dict[str, JSONValue]:
    """Flatten a nested ``dict``/``list`` tree into dotted-key form."""
    result: dict[str, JSONValue] = {}
    for key, value in node.items():
        full: str = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            _ = result.update(flatten_tree(node=value, prefix=full))
        elif isinstance(value, list):
            for index, item in enumerate(iterable=value):
                if isinstance(item, dict):
                    _ = result.update(
                        flatten_tree(node=item, prefix=f"{full}[{index}]"),
                    )
                else:
                    result[f"{full}[{index}]"] = item
        else:
            result[full] = value
    return result


def deep_merge(
    left: dict[str, JSONValue],
    right: dict[str, JSONValue],
) -> dict[str, JSONValue]:
    """Recursively merge two dict trees; ``right`` wins on conflicts."""
    merged: dict[str, JSONValue] = dict(left)
    for key, value in right.items():
        if (
            key in merged
            and isinstance(merged[key], dict)
            and isinstance(value, dict)
        ):
            merged[key] = deep_merge(
                left=cast_dict(value=merged[key]),
                right=cast_dict(value=value),
            )
        else:
            merged[key] = value
    return merged


def cast_dict(value: JSONValue) -> dict[str, JSONValue]:
    """Return cast dict.

    Args:
        value (JSONValue): The value value passed to the call.

    Returns:
        The computed value of type ``dict[str, JSONValue]``.

    """
    return value if isinstance(value, dict) else {}


# =============================================================================
# 50. Algorithm patterns — magic-number-rich math/sort/search
# =============================================================================


def binary_search(items: list[int], target: int) -> int:
    """Return binary search.

    Args:
        items (list[int]): The items value passed to the call.
        target (int): The target value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    low, high = 0, len(items) - 1
    while low <= high:
        mid: float = (low + high) // 2
        if items[mid] == target:
            return mid
        if items[mid] < target:
            low: float = mid + 1
        else:
            high: float = mid - 1
    return -1


def insertion_sort(items: list[int]) -> list[int]:
    """Return insertion sort.

    Args:
        items (list[int]): The items value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    out: list[int] = list(items)
    for i in range(1, len(out)):
        current: int = out[i]
        j: int = i - 1
        while j >= 0 and out[j] > current:
            out[j + 1] = out[j]
            j -= 1
        out[j + 1] = current
    return out


def fibonacci_iter(limit: int) -> list[int]:
    """Return fibonacci iter.

    Args:
        limit (int): The limit value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    out: list[int] = []
    a, b = 0, 1
    while a < limit:
        _ = out.append(a)
        a, b = b, a + b
    return out


def gcd(a: int, b: int) -> int:
    """Return gcd.

    Args:
        a (int): The a value passed to the call.
        b (int): The b value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    while b:
        a, b = b, a % b
    return a


def lcm(a: int, b: int) -> int:
    """Return lcm.

    Args:
        a (int): The a value passed to the call.
        b (int): The b value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    return abs(a * b) // gcd(a=a, b=b) if a and b else 0


def factorial(n: int) -> int:
    """Return factorial.

    Args:
        n (int): The n value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    if n < 0:
        return 0
    result: int = 1
    for k in range(2, n + 1):
        result *= k
    return result


def power_mod(base: int, exp: int, modulus: int) -> int:
    """Return power mod.

    Args:
        base (int): The base value passed to the call.
        exp (int): The exp value passed to the call.
        modulus (int): The modulus value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    result: int = 1 % modulus
    current: int = base % modulus
    while exp > 0:
        if exp & 1:
            result = (result * current) % modulus
        current = (current * current) % modulus
        exp >>= 1
    return result


# =============================================================================
# 51. String parsing — state-machine style with explicit transitions
# =============================================================================


def parse_csv_row(line: str) -> list[str]:
    """Return parse csv row.

    Args:
        line (str): The line value passed to the call.

    Returns:
        The computed value of type ``list[str]``.

    """
    fields: list[str] = []
    buffer: list[str] = []
    in_quotes: bool = False
    for char in line:
        if char == '"':
            in_quotes = not in_quotes
        elif char == "," and not in_quotes:
            _ = fields.append("".join(buffer))
            _ = buffer.clear()
        else:
            _ = buffer.append(char)
    _ = fields.append("".join(buffer))
    return fields


def tokenize_simple(text: str) -> list[str]:
    """Return tokenize simple.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``list[str]``.

    """
    tokens: list[str] = []
    current: list[str] = []
    for char in text:
        if char.isalnum() or char == "_":
            _ = current.append(char)
            continue
        if current:
            _ = tokens.append("".join(current))
            _ = current.clear()
        if not char.isspace():
            _ = tokens.append(char)
    if current:
        _ = tokens.append("".join(current))
    return tokens


def strip_comments(source: str) -> str:
    """Return strip comments.

    Args:
        source (str): The source value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    lines: list[str] = source.splitlines()
    cleaned: list[str] = []
    for line in lines:
        idx: int = line.find("#")
        _ = cleaned.append(line[:idx].rstrip() if idx >= 0 else line)
    return "\n".join(cleaned)


# =============================================================================
# 52. Graph / tree data structures — recursive methods exercise inference
# =============================================================================


@dataclass
class TreeNode:
    """Binary tree node with value and optional children."""

    value: int
    left: TreeNode | None = None
    right: TreeNode | None = None

    def depth(self) -> int:
        """Return depth.

        Returns:
            The computed value of type ``int``.

        """
        left_depth: int = 0 if self.left is None else self.left.depth()
        right_depth: int = 0 if self.right is None else self.right.depth()
        return 1 + max(left_depth, right_depth)

    def in_order(self) -> list[int]:
        """Return in order.

        Returns:
            The computed value of type ``list[int]``.

        """
        result: list[int] = []
        if self.left is not None:
            _ = result.extend(self.left.in_order())
        _ = result.append(self.value)
        if self.right is not None:
            _ = result.extend(self.right.in_order())
        return result

    def insert(self, value: int) -> None:
        """Return insert.

        Args:
            value (int): The value value passed to the call.

        """
        if value < self.value:
            if self.left is None:
                self.left = TreeNode(value=value)
            else:
                _ = self.left.insert(value=value)
        elif self.right is None:
            self.right = TreeNode(value=value)
        else:
            _ = self.right.insert(value=value)


@dataclass
class Graph:
    """Adjacency-list graph keyed by node id."""

    adjacency: dict[int, list[int]] = field(default_factory=dict)

    def add_edge(self, source: int, target: int) -> None:
        """Return add edge.

        Args:
            source (int): The source value passed to the call.
            target (int): The target value passed to the call.

        """
        _ = self.adjacency.setdefault(source, []).append(target)
        _ = self.adjacency.setdefault(target, []).append(source)

    def bfs(self, start: int) -> list[int]:
        """Return bfs.

        Args:
            start (int): The start value passed to the call.

        Returns:
            The computed value of type ``list[int]``.

        """
        visited: set[int] = {start}
        order: list[int] = [start]
        frontier: list[int] = [start]
        while frontier:
            current: int = frontier.pop(0)
            for neighbour in self.adjacency.get(current, []):
                if neighbour in visited:
                    continue
                _ = visited.add(neighbour)
                _ = order.append(neighbour)
                _ = frontier.append(neighbour)
        return order

    def neighbours(self, node: int) -> list[int]:
        """Return neighbours.

        Args:
            node (int): The node value passed to the call.

        Returns:
            The computed value of type ``list[int]``.

        """
        return list(self.adjacency.get(node, []))


# =============================================================================
# 53. Numeric helpers — statistics-like with float divisors
# =============================================================================


def mean(values: list[float]) -> float:
    """Return mean.

    Args:
        values (list[float]): The values value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    return sum(values) / len(values) if values else 0.0


def variance(values: list[float]) -> float:
    """Return variance.

    Args:
        values (list[float]): The values value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if len(values) < Constants.int_2:
        return 0.0
    avg: float = mean(values=values)
    return sum((v - avg) ** 2 for v in values) / (len(values) - 1)


def stdev(values: list[float]) -> float:
    """Return stdev.

    Args:
        values (list[float]): The values value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    return variance(values=values) ** 0.5


def median(values: list[float]) -> float:
    """Return median.

    Args:
        values (list[float]): The values value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if not values:
        return 0.0
    sorted_values: list[float] = sorted(values)
    middle: int = len(sorted_values) // 2
    if len(sorted_values) % 2:
        return sorted_values[middle]
    return (sorted_values[middle - 1] + sorted_values[middle]) / 2


def clip(value: float, low: float, high: float) -> float:
    """Return clip.

    Args:
        value (float): The value value passed to the call.
        low (float): The low value passed to the call.
        high (float): The high value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    return max(low, min(value, high))


def lerp(start: float, end: float, t: float) -> float:
    """Return lerp.

    Args:
        start (float): The start value passed to the call.
        end (float): The end value passed to the call.
        t (float): The t value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    return start + (end - start) * t


def remap(
    value: float,
    src_low: float,
    src_high: float,
    dst_low: float,
    dst_high: float,
) -> float:
    """Return remap.

    Args:
        value (float): The value value passed to the call.
        src_low (float): The src low value passed to the call.
        src_high (float): The src high value passed to the call.
        dst_low (float): The dst low value passed to the call.
        dst_high (float): The dst high value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if src_high == src_low:
        return dst_low
    ratio: float = (value - src_low) / (src_high - src_low)
    return dst_low + (dst_high - dst_low) * ratio


# =============================================================================
# 54. Long prose docstring — many paragraphs + Examples + See also
# =============================================================================


def long_prose_doc(value: str) -> str:
    """Demonstrate paragraph-wrapped long-form prose with sections.

    This first paragraph is intentionally extensive so the wrapper has
    something substantial to fold across multiple physical lines. The
    autowrap pass should preserve sentence boundaries, keep punctuation
    flush against the preceding word, and avoid breaking inside inline
    ``code`` spans or URLs like https://example.com/wrap-me-not.

    A second paragraph follows after a blank line. It must remain a
    distinct paragraph rather than merging with the first; the wrapper
    respects blank-line separators. Within this paragraph we exercise
    *emphasis*, **strong emphasis**, and ``inline code`` markers — all
    must round-trip cleanly through the rendering pass without becoming
    plain text and without altering whitespace inside the markers.

    A third paragraph contains a single very long sentence with no
    natural break points that must be folded by the wrapper using the
    width budget rather than punctuation cues to choose its breaks.

    Note:
        The Examples block above uses the doctest convention and
        must survive the docstring normaliser without indentation drift.

    See Also:
        :func:`forward_narrow_pipeline`: a related forward-inference demo.
        :func:`call_packet_helpers`: a related backward-inference demo.

    Args:
        value (str): The input string to echo back; its presence forces
            the wrapper to emit an Args block with a multi-line entry
            whose continuation must indent under the parameter name.

    Returns:
        str: The input string returned verbatim. Documented across
            multiple lines to verify the Returns block alignment.

    Raises:
        ValueError: Never actually raised; documented so the
            Raises section receives a multi-line entry whose
            continuation indents under the exception name.

    Examples:
        Basic usage with a single short argument:

            >>> long_prose_doc("hi")
            'hi'

        Round-tripping a longer literal:

            >>> long_prose_doc("hello, world")
            'hello, world'

    """
    return value


# =============================================================================
# 55. Yields section — generator with documented yield type
# =============================================================================


def chunk_iter(values: list[int], size: int) -> Generator[list[int]]:
    """Yield successive ``size``-sized chunks of ``values``.

    Args:
        values (list[int]): The source sequence to chunk.
        size (int): Number of elements in each yielded chunk; the final chunk
            may be smaller if ``len(values)`` is not divisible.

    Yields:
        list[int]: A slice of ``values`` of length ``<= size``.

    Raises:
        ValueError: If ``size`` is less than one.

    """
    if size < 1:
        msg: str = "size must be >= 1"
        raise ValueError(msg)
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


def stride_iter(values: list[int], step: int) -> Generator[int]:
    """Yield values at the given ``step`` interval.

    Args:
        values (list[int]): The source sequence.
        step (int): Stride between successive yielded items.

    Yields:
        int: Every ``step``-th item from ``values``.

    """
    for index in range(0, len(values), step):
        yield values[index]


# =============================================================================
# 56. Deeply nested generics — Mapping[str, list[tuple[int, set[str]]]]
# =============================================================================


def index_records(
    rows: list[tuple[str, int, str]],
) -> dict[str, list[tuple[int, set[str]]]]:
    """Bucket rows by category, aggregating ids and tags.

    Args:
        rows (list[tuple[str, int, str]]): 3-tuples of (category, id, tag).

    Returns:
        A mapping from category to a list of (id, set-of-tags) entries.

    """
    out: dict[str, list[tuple[int, set[str]]]] = {}
    for category, row_id, tag in rows:
        bucket: list[tuple[int, set[str]]] = out.setdefault(category, [])
        # Try merge into existing entry with the same id.
        merged: bool = False
        for index, (existing_id, tags) in enumerate(iterable=bucket):
            if existing_id == row_id:
                bucket[index] = (existing_id, tags | {tag})
                merged = True
                break
        if not merged:
            _ = bucket.append((row_id, {tag}))
    return out


def matrix_transpose(matrix: list[list[float]]) -> list[list[float]]:
    """Return matrix transpose.

    Args:
        matrix (list[list[float]]): The matrix value passed to the call.

    Returns:
        The computed value of type ``list[list[float]]``.

    """
    if not matrix:
        return []
    cols: int = len(matrix[0])
    return [[row[col] for row in matrix] for col in range(cols)]


def nested_lookup(
    table: dict[str, dict[str, list[int]]],
    outer: str,
    inner: str,
) -> list[int]:
    """Return nested lookup.

    Args:
        table (dict[str, dict[str, list[int]]]): The table value passed to the call.
        outer (str): The outer value passed to the call.
        inner (str): The inner value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    return list(table.get(outer, {}).get(inner, []))


# =============================================================================
# 57. dict/list narrowing chains — many isinstance branches
# =============================================================================


def coerce_value(value: JSONValue) -> str:
    """Return coerce value.

    Args:
        value (JSONValue): The value value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if isinstance(value, str):
        return value
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".3f")
    if isinstance(value, list):
        parts: list[str] = [coerce_value(value=item) for item in value]
        return ",".join(parts)
    if isinstance(value, dict):
        kv_parts: list[str] = []
        for key, item in value.items():
            _ = kv_parts.append(str(key) + "=" + coerce_value(value=item))
        return ";".join(kv_parts)
    return "" if value is None else repr(value)


def flatten_lists_of_lists(values: list[list[int] | int]) -> list[int]:
    """Return flatten lists of lists.

    Args:
        values (list[list[int] | int]): The values value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    out: list[int] = []
    for item in values:
        _ = out.extend(item) if isinstance(item, list) else out.append(item)
    return out


def type_summary(values: list[object]) -> dict[str, int]:
    """Return type summary.

    Args:
        values (list[object]): The values value passed to the call.

    Returns:
        The computed value of type ``dict[str, int]``.

    """
    summary: dict[str, int] = {}
    for value in values:
        if isinstance(value, bool):
            key: str = "bool"
        elif isinstance(value, int):
            key = "int"
        elif isinstance(value, float):
            key = "float"
        elif isinstance(value, str):
            key = "str"
        elif isinstance(value, list):
            key = "list"
        elif isinstance(value, dict):
            key = "dict"
        else:
            key = "other"
        summary[key] = summary.get(key, 0) + 1
    return summary


# =============================================================================
# 58. Even more magic numbers — pricing/billing rules
# =============================================================================


def quarterly_rate(annual: float, quarter: int) -> float:
    """Return quarterly rate.

    Args:
        annual (float): The annual value passed to the call.
        quarter (int): The quarter value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if quarter == 1:
        return annual * 0.22
    if quarter == Constants.int_2:
        return annual * 0.27
    if quarter == Constants.int_3:
        return annual * 0.26
    return annual * 0.25


def shipping_cost(weight_kg: float, distance_km: float) -> float:
    """Return shipping cost.

    Args:
        weight_kg (float): The weight kg value passed to the call.
        distance_km (float): The distance km value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    base: float = 4.5
    weight_fee: float = weight_kg * 1.2
    distance_fee: float = distance_km * 0.08
    if distance_km > Constants.int_500:
        distance_fee += 12.0
    if weight_kg > Constants.int_20:
        weight_fee += 18.0
    return base + weight_fee + distance_fee


def tier_for_score(score: int) -> str:
    """Return tier for score.

    Args:
        score (int): The score value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if score >= Constants.int_950:
        return "platinum"
    if score >= Constants.int_850:
        return "gold"
    if score >= Constants.int_750:
        return "silver"
    if score >= Constants.int_600:
        return "bronze"
    return "none"


def piecewise_tax(income: float) -> float:
    """Return piecewise tax.

    Args:
        income (float): The income value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    if income <= Constants.int_10000:
        return income * 0.08
    if income <= Constants.int_50000:
        return Constants.int_800 + (income - Constants.int_10000) * 0.15
    if income <= Constants.int_200000:
        return Constants.int_6800 + (income - Constants.int_50000) * 0.24
    return Constants.int_42800 + (income - Constants.int_200000) * 0.33


# =============================================================================
# 59. Larger method-sort exercise — full canonical-order test class
# =============================================================================


class FullScrambledClass:
    """Class with every canonical-order category present and misordered."""

    _internal_state: int = 0

    def __init__(self) -> None:
        """Return init."""
        self._internal_state = 0

    def __eq__(self, other: object) -> bool:
        """Return eq."""
        return (
            isinstance(other, FullScrambledClass)
            and other._internal_state == self._internal_state
        )

    def __hash__(self) -> int:
        """Return hash."""
        return hash(self._internal_state)

    def __len__(self) -> int:
        """Return len."""
        return abs(self._internal_state)

    @override
    def __repr__(self) -> str:
        """Return repr."""
        return f"FullScrambledClass(state={self._internal_state})"

    @property
    def state(self) -> int:
        """Return state.

        Returns:
            The computed value of type ``int``.

        """
        return self._internal_state

    @classmethod
    def from_dict(cls, payload: dict[str, int]) -> FullScrambledClass:
        """Return from dict.

        Args:
            payload (dict[str, int]): The payload value passed to the call.

        Returns:
            The computed value of type ``FullScrambledClass``.

        """
        instance: FullScrambledClass = cls()
        instance._internal_state = payload.get("state", 0)
        return instance

    @staticmethod
    def signature() -> str:
        """Return signature.

        Returns:
            The computed value of type ``str``.

        """
        return "FullScrambledClass"

    def adjust(self, delta: int) -> int:
        """Return adjust.

        Args:
            delta (int): The delta value passed to the call.

        Returns:
            The computed value of type ``int``.

        """
        self._internal_state += delta
        return self._internal_state

    def _internal_helper(self) -> int:
        """Return internal helper."""
        return self._internal_state


# =============================================================================
# 60. Yet another autokwargs exercise — many positional stdlib calls
# =============================================================================


def lots_of_positional_calls(
    target_dir: Path,
    items: list[str],
    delim: str,
) -> dict[str, int]:
    """Return lots of positional calls.

    Args:
        target_dir (Path): The target dir value passed to the call.
        items (list[str]): The items value passed to the call.
        delim (str): The delim value passed to the call.

    Returns:
        The computed value of type ``dict[str, int]``.

    """
    joined: str = delim.join(items)
    out_path: Path = target_dir / "joined.txt"
    _ = out_path.write_text(data=joined, encoding="utf-8")
    counts: Counter[str] = Counter(items)
    top: list[tuple[str, int]] = counts.most_common(n=3)
    return dict(top)


def regex_pipeline(text: str) -> dict[str, str]:
    """Return regex pipeline.

    Args:
        text (str): The text value passed to the call.

    Returns:
        The computed value of type ``dict[str, str]``.

    """
    return {
        "compact": sub(pattern=r"\s+", repl=" ", string=text),
        "upper_alpha": sub(pattern=r"[^A-Z]", repl="", string=text.upper()),
        "first_word": split(pattern=r"\s+", string=text.strip())[0]
        if text.strip()
        else "",
        "letters_only": sub(pattern=r"[^A-Za-z]", repl="", string=text),
    }


def slice_helpers(items: list[int]) -> dict[str, list[int]]:
    """Return slice helpers.

    Args:
        items (list[int]): The items value passed to the call.

    Returns:
        The computed value of type ``dict[str, list[int]]``.

    """
    return {
        "first_three": items[:3],
        "last_three": items[-3:],
        "middle": items[len(items) // 4 : -len(items) // 4]
        if len(items) >= Constants.int_4
        else [],
        "evens": items[::2],
        "reversed": items[::-1],
    }


# =============================================================================
# 61. Edge-case docstring wrapping — embedded blockquotes and citations
# =============================================================================


def docstring_with_blockquote(value: str) -> str:
    """Docstring with embedded quotes and citation styles.

    Inline quote followed by attribution:

        "Premature optimization is the root of all evil."
            — Donald Knuth, *Structured Programming with go to Statements*

    A second blockquote, multi-paragraph:

        First quoted paragraph spanning enough words that the wrapper
        has to fold the quote across multiple lines while preserving
        the leading indentation that marks it as a blockquote.

        Second quoted paragraph; both belong to the same quote block
        and the blank-line separator between them must survive the
        wrap pass.

    A code block follows the quote to verify the wrapper
    doesn't accidentally promote prose into the code block:

        result = docstring_with_blockquote("x")
        assert result == "x"

    Args:
        value (str): A simple string echo argument.

    Returns:
        str: The unchanged input value.

    """
    return value


# =============================================================================
# 62. Forward + backward inference loop — call-site propagates upstream
# =============================================================================


def upstream_consumer(payload: str) -> tuple[str, str]:
    """Return upstream consumer.

    Args:
        payload (str): The payload value passed to the call.

    Returns:
        The computed value of type ``tuple[str, str]``.

    """
    parts: list[str] = payload.split(sep="=", maxsplit=1)
    return parts[0], parts[1]


def upstream_aggregator(items: Iterable[str]) -> list[tuple[str, str]]:
    """Return upstream aggregator.

    Args:
        items (Iterable[str]): The items value passed to the call.

    Returns:
        The computed value of type ``list[tuple[str, str]]``.

    """
    return [upstream_consumer(payload=item) for item in items]


def driver_for_inference() -> list[tuple[str, str]]:
    """Return driver for inference.

    Returns:
        The computed value of type ``list[tuple[str, str]]``.

    """
    fixed: list[str] = ["k1=v1", "k2=v2", "k3=v3"]
    return upstream_aggregator(items=fixed)


# =============================================================================
# 63. Closure tracking — inner function captures outer typed parameter
# =============================================================================
# autotype's nonlocal-tracking pass should infer the inner function's
# parameters from how it uses values closed-over from the enclosing scope.
# (See docs/README_autotype.md → "Closure Tracking".)


def make_adder(base: int) -> Callable[[int], int]:
    """Return make adder.

    Args:
        base (int): The base value passed to the call.

    Returns:
        The computed value of type ``Callable[[int], int]``.

    """

    def adder(amount: int) -> int:
        """Return adder.

        Args:
            amount (int): The amount value passed to the call.

        Returns:
            The computed value of type ``int``.

        """
        return base + amount

    return adder


def make_indexed_getter(prefix: str) -> Callable[[str], str]:
    """Return make indexed getter.

    Args:
        prefix (str): The prefix value passed to the call.

    Returns:
        The computed value of type ``Callable[[str], str]``.

    """

    def get(key: str) -> str:
        """Return get.

        Args:
            key (str): The key value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return prefix + "." + key

    return get


def use_closures() -> tuple[int, str]:
    """Return use closures.

    Returns:
        The computed value of type ``tuple[int, str]``.

    """
    add5: Callable[[int], int] = make_adder(base=5)
    label: Callable[[str], str] = make_indexed_getter(prefix="env")
    return add5(7), label("PATH")


# =============================================================================
# 64. String alias synthesis — repeated Literal unions across params
# =============================================================================
# When two distinct functions narrow on the same finite string set,
# autotype's alias synthesizer hoists the union into a single named
# Literal alias so the annotations stay DRY. (See
# docs/README_autotype.md → "String Alias Synthesis".)


def process_status(status: str) -> bool:
    """Return process status.

    Args:
        status (str): The status value passed to the call.

    Returns:
        The computed value of type ``bool``.

    """
    if status == "active":
        return True
    if status == "inactive":
        return False
    return False


def handle_mode(mode: str) -> int:
    """Return handle mode.

    Args:
        mode (str): The mode value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    if mode == "active":
        return 1
    if mode == "inactive":
        return 0
    return -1


def render_state(state: str) -> str:
    """Return render state.

    Args:
        state (str): The state value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if state == "active":
        return ">"
    if state == "inactive":
        return "."
    return "?"


# =============================================================================
# 65. Memoization pattern — manual cache dict synthesized as concrete dict
# =============================================================================
# autotype detects the ``if x in cache: return cache[x]; cache[x] =
# result`` shape and annotates ``cache`` from the values it stores
# rather than leaving it ``dict[object, object]``. (See
# docs/README_autotype.md → "Memoization Pattern".)


def cached_fib(n: int) -> int:
    """Return cached fib.

    Args:
        n (int): The n value passed to the call.

    Returns:
        The computed value of type ``int``.

    """
    if n in Constants.fib_cache:
        return Constants.fib_cache[n]
    result: int = (
        n if n < Constants.int_2 else cached_fib(n=n - 1) + cached_fib(n=n - 2)
    )
    Constants.fib_cache[n] = result
    return result


def cached_title(value: str) -> str:
    """Return cached title.

    Args:
        value (str): The value value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    if value in Constants.title_cache:
        return Constants.title_cache[value]
    result: str = value.strip().title()
    Constants.title_cache[value] = result
    return result


# =============================================================================
# 66. Override decorator addition — subclass methods missing @override
# =============================================================================
# autotype walks subclass MROs and inserts ``@override`` on every method that
# already exists on a base class. (See docs/README_autotype.md → "Override
# Decorator Addition".) The base ``Greeter`` declares the contract; the two
# subclasses below override ``greet`` / ``__repr__`` *without* the decorator
# at the def-site — the pipeline should add it.


class Greeter:
    """Friendly base whose subclasses customise the greeting verb."""

    @override
    def __repr__(self) -> str:
        """Return repr."""
        return "Greeter()"

    def greet(self, name: str) -> str:
        """Return greet.

        Args:
            name (str): The name value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return "hi " + name


class FormalGreeter(Greeter):
    """Subclass overriding both base methods without the decorator."""

    @override
    def __repr__(self) -> str:
        """Return repr."""
        return "FormalGreeter()"

    @override
    def greet(self, name: str) -> str:
        """Return greet.

        Args:
            name (str): The name value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return "Good day, " + name + "."


class CasualGreeter(Greeter):
    """Subclass overriding only ``greet``."""

    @override
    def greet(self, name: str) -> str:
        """Return greet.

        Args:
            name (str): The name value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return "yo " + name


# =============================================================================
# 67. Module-level annotations — unannotated constants
# =============================================================================
# autotype's module-level annotation pass should turn each of these right-
# hand-side-inferred assignments into typed declarations (``int`` /
# ``list[object]`` / ``dict[str, int]`` / ``tuple[int, int, int]``). (See
# docs/README_autotype.md → "Module-Level Annotations".)


def batch_summary() -> str:
    """Return batch summary.

    Returns:
        The computed value of type ``str``.

    """
    return (
        f"batch={Constants.default_batch_size} tags={Constants.known_tags!r} "
        f"priorities={Constants.priority_levels!r} channel={Constants.channel_rgb!r}"
    )


# =============================================================================
# 68. Escaped-newline literals → dedent(text=...) auto-conversion
# =============================================================================
# autowrap's `NewlineAndDedentStringFormatter` rewrites every plain string
# literal containing ``\n`` escapes into a triple-quoted
# ``dedent(text="""…""")`` block, and adds ``from textwrap import dedent``
# when the module doesn't already import it. The originals below are
# deliberately short-ish multi-line escapes that the conversion heuristic
# considers worth rewriting (more than one ``\n`` and at least one non-blank
# line in the value).


def render_html_skeleton() -> str:
    """Return render html skeleton.

    Returns:
        The computed value of type ``str``.

    """
    return dedent(
        text="""\
                <html>
                  <body>
                    <p>placeholder</p>
                  </body>
                </html>
            """,
    )


def render_help_banner() -> str:
    """Return render help banner.

    Returns:
        The computed value of type ``str``.

    """
    return dedent(
        text="""\
            USAGE: tool [options] FILE

            OPTIONS:
              --help    show help
        """,
    )


def render_sql_template(table: str) -> str:
    """Return render sql template.

    Args:
        table (str): The table value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    base: str = dedent(
        text="""\
                SELECT id, name, value
                FROM TABLE_NAME
                WHERE active = TRUE
                ORDER BY id;
            """,
    )
    return base.replace("TABLE_NAME", table)


# =============================================================================
# 69. Docstring-extracted type hints — comment-based & doctstring-based
# =============================================================================
# autotype's docstring parser pulls explicit ``Args:`` types out of a Google
# block when the def-site lacks annotations and the docstring carries an
# unambiguous one. (See docs/README_autotype.md → "Docstring Parsing".)


def parse_with_doc_types(raw: str, retries: int) -> list[str]:
    """Parse ``raw`` with bounded retries.

    Args:
        raw (str): The raw text to parse — annotation deliberately omitted on
            the ``def`` line so autotype must read the docstring to
            recover the type.
        retries (int): Number of times to retry on transient failure.

    Returns:
        list[str]: Parsed tokens.

    """
    attempt: int = 0
    while attempt < retries:
        tokens: list[str] = raw.split(sep=":")
        if tokens:
            return tokens
        attempt += 1
    return []


# =============================================================================
# 70. Decorator awareness in autokwargs — @staticmethod / @classmethod
# =============================================================================
# autokwargs resolves the receiver kind correctly for ``@staticmethod``
# and ``@classmethod`` calls and adds keyword names even when the caller
# goes through the *class* rather than an instance. (See
# docs/README_autokwargs.md → "Decorator awareness".)


class Registry:
    """Class whose static and class methods are called positionally."""

    label: str = ""

    @classmethod
    def from_pair(cls, head: str, tail: str) -> Registry:
        """Return from pair.

        Args:
            head (str): The head value passed to the call.
            tail (str): The tail value passed to the call.

        Returns:
            The computed value of type ``Registry``.

        """
        instance: Registry = cls()
        instance.label = head + "/" + tail
        return instance

    @staticmethod
    def stamp(prefix: str, value: str) -> str:
        """Return stamp.

        Args:
            prefix (str): The prefix value passed to the call.
            value (str): The value value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return prefix + ":" + value


def call_registry() -> tuple[str, Registry]:
    """Return call registry.

    Returns:
        The computed value of type ``tuple[str, Registry]``.

    """
    return Registry.stamp(
        prefix="env",
        value="production",
    ), Registry.from_pair(head="a", tail="b")


# =============================================================================
# 71. Function-scope magic values — autoinsert local-extraction
# =============================================================================
# When ``magic-values-scope=function`` is set, autoinsert hoists numeric
# literals inside *one* function into a local constant rather than a module-
# level one. The header runs in module-scope so this section is here to
# demonstrate the *expression density* that an inner-scope extraction would
# normalise; switch the header to ``function`` to see the difference.


def physics_step(velocity: float, acceleration: float) -> float:
    """Return physics step.

    Args:
        velocity (float): The velocity value passed to the call.
        acceleration (float): The acceleration value passed to the call.

    Returns:
        The computed value of type ``float``.

    """
    drag: float = velocity * 0.97
    push: float = acceleration * 1.21
    floor: float = max(drag + push, 0.0)
    return min(floor, 99.5)


# =============================================================================
# 72. PEP 695 generic functions — autotype on the new type-param syntax
# =============================================================================
# Type-parameter syntax (``def f[T](...)``) lets autotype infer the element
# type from the bound. The body uses ``x`` as if it were ``T`` — no extra
# annotation should be needed at the def site.


def first_of[T](items: list[T]) -> T | None:
    """Return first of.

    Args:
        items (list[T]): The items value passed to the call.

    Returns:
        The computed value of type ``T | None``.

    """
    if not items:
        return None
    return items[0]


def pair_keys[K, V](mapping: dict[K, V]) -> list[K]:
    """Return pair keys.

    Args:
        mapping (dict[K, V]): The mapping value passed to the call.

    Returns:
        The computed value of type ``list[K]``.

    """
    return list(mapping.keys())


# =============================================================================
# 73. TypeAlias hoisting — explicit ``type Foo = ...`` (PEP 695)
# =============================================================================
# autotype recognises PEP 695 type-alias statements and treats the RHS as a
# real type expression when inferring downstream annotations.


def normalise_primitive(value: JSONPrimitive) -> str:
    """Return normalise primitive.

    Args:
        value (JSONPrimitive): The value value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return "null" if value is None else str(value)


def join_string_list(parts: StringList, sep: str = ", ") -> str:
    """Return join string list.

    Args:
        parts (StringList): The parts value passed to the call.
        sep (str): The sep value passed to the call.

    Returns:
        The computed value of type ``str``.

    """
    return sep.join(parts)


# =============================================================================
# 74. Async generator — autotype's ``AsyncIterator`` return inference
# =============================================================================
# An ``async def`` whose body uses ``yield`` should be annotated as
# ``AsyncIterator[...]``; the element type is inferred from the yield expr.


async def count_async(limit: int) -> AsyncIterator[int]:
    """Return count async.

    Args:
        limit (int): The limit value passed to the call.

    Returns:
        The computed value of type ``AsyncIterator[int]``.

    """
    n: int = 0
    while n < limit:
        yield n
        n += 1
        await sleep(delay=0)


async def collect_async(limit: int) -> list[int]:
    """Return collect async.

    Args:
        limit (int): The limit value passed to the call.

    Returns:
        The computed value of type ``list[int]``.

    """
    return [value async for value in count_async(limit=limit)]


# =============================================================================
# 75. Context manager protocol — ``__enter__`` / ``__exit__`` self-typing
# =============================================================================
# autotype should annotate ``__enter__`` as returning ``Self`` and
# ``__exit__`` as returning ``bool | None`` with the standard exception-info
# signature.


class Transaction:
    """Represent Transaction."""

    def __init__(self, label: str) -> None:
        """Return init.

        Args:
            label (str): The label value passed to the call.

        """
        self.label: str = label
        self.entered: bool = False

    def __enter__(self) -> Self:
        """Return enter."""
        self.entered = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> bool:
        """Return exit."""
        self.entered = False
        return False


# =============================================================================
# 76. Additional inference stress cases — factories, scopes, overload-like
# flows
# =============================================================================
# These cases intentionally stress places where automatic typing tools
# commonly fall back to ``object`` or accidentally change runtime behavior.


@dataclass
class EventLog:
    """Dataclass whose builtin generic factories stay unparameterized."""

    names: list[object] = field(default_factory=list)
    counts: dict[object, float] = field(default_factory=dict)
    seen: set[object] = field(default_factory=set)

    def add(self, name: object, amount: float = 1) -> Self:
        """Return add.

        Args:
            name (object): The name value passed to the call.
            amount (float): The amount value passed to the call.

        Returns:
            The computed value of type ``Self``.

        """
        _ = self.names.append(name)
        self.counts[name] = self.counts.get(name, 0) + amount
        _ = self.seen.add(name)
        return self

    def summary(self) -> dict[object, object]:
        """Return summary.

        Returns:
            The computed value of type ``dict[object, object]``.

        """
        return {name: self.counts[name] for name in self.seen}


@dataclass
class KeyValueStore:
    """Stateful generic candidate using one key type and one value type."""

    values: dict[object, float] = field(default_factory=dict)

    def get_or(self, key: object, default: object) -> object:
        """Return get or.

        Args:
            key (object): The key value passed to the call.
            default (object): The default value passed to the call.

        Returns:
            The computed value of type ``object``.

        """
        return self.values.get(key, default)

    def keys_list(self) -> list[object]:
        """Return keys list.

        Returns:
            The computed value of type ``list[object]``.

        """
        return list(self.values.keys())

    def put(self, key: object, value: int) -> object:
        """Return put.

        Args:
            key (object): The key value passed to the call.
            value (int): The value value passed to the call.

        Returns:
            The computed value of type ``object``.

        """
        previous: object = self.values.get(key)
        self.values[key] = value
        return previous

    def values_list(self) -> list[object]:
        """Return values list.

        Returns:
            The computed value of type ``list[object]``.

        """
        return list(self.values.values())


class FluentCounter:
    """Self-returning mutator should infer Self for fluent methods."""

    def __init__(self) -> None:
        """Return init."""
        self.total: int = 0

    @classmethod
    def from_values(cls, values: Iterable[int]) -> FluentCounter:
        """Return from values.

        Args:
            values (Iterable[int]): The values value passed to the call.

        Returns:
            The computed value of type ``FluentCounter``.

        """
        instance: FluentCounter = cls()
        for value in values:
            _: Self = instance.add(amount=value)
        return instance

    def add(self, amount: int) -> Self:
        """Return add.

        Args:
            amount (int): The amount value passed to the call.

        Returns:
            The computed value of type ``Self``.

        """
        self.total += amount
        return self

    def reset(self) -> Self:
        """Return reset.

        Returns:
            The computed value of type ``Self``.

        """
        self.total = 0
        return self


class LazyValue:
    """Property and cached state should keep optional narrowing precise."""

    def __init__(self, raw: str) -> None:
        """Return init.

        Args:
            raw (str): The raw value passed to the call.

        """
        self.raw: str = raw
        self._cached: str | None = None

    @property
    def value(self) -> str:
        """Return value."""
        if self._cached is None:
            self._cached = self.raw.strip().lower()
        return self._cached


class Descriptor:
    """Simple descriptor stress case for __get__ and __set__."""

    def __init__(self, default: object) -> None:
        """Return init.

        Args:
            default (object): The default value passed to the call.

        """
        self.default: object = default
        self.name: str = ""

    def __get__(
        self,
        instance: object | None,
        owner: type[object] | None = None,
    ) -> Self | object:
        """Return get."""
        if instance is None:
            return self
        return instance.__dict__.get(self.name, self.default)

    def __set__(self, instance: object, value: object) -> None:
        """Return set."""
        instance.__dict__[self.name] = value

    def __set_name__(self, owner: type[object], name: str) -> None:
        """Return set name."""
        self.name = name


class DescriptorUser:
    """Represent DescriptorUser."""

    label: Descriptor = Descriptor(default="unknown")

    def rename(self, value: str) -> object:
        """Return rename.

        Args:
            value (str): The value value passed to the call.

        Returns:
            The computed value of type ``object``.

        """
        self.label = value
        return self.label


class _SentinelMissing(Enum):
    """Internal sentinel for context-manager identity narrowing."""

    TOKEN = auto()


_SENTINEL_MISSING: Final = _SentinelMissing.TOKEN


@contextmanager
def temporary_mapping_value[K, V](
    mapping: MutableMapping[K, V],
    key: K,
    value: V,
) -> Generator[V | None]:
    """Context manager should infer the yielded previous value."""
    previous: V | _SentinelMissing = mapping.get(key, _SENTINEL_MISSING)
    mapping[key] = value
    try:
        yield previous if previous is not _SENTINEL_MISSING else None
    finally:
        if previous is _SENTINEL_MISSING:
            _ = mapping.pop(key, None)
        else:
            mapping[key] = previous


def select_first_present(
    primary: str | None,
    secondary: str | None,
    fallback: str,
) -> str:
    """Identity-preserving union/narrowing across three candidate values."""
    if primary is not None:
        return primary
    if secondary is not None:
        return secondary
    return fallback


def transpose_pairs[A, B](
    pairs: Iterable[tuple[A, B]],
) -> tuple[list[A], list[B]]:
    """Infer tuple element relationships without collapsing to object."""
    left: list[A] = []
    right: list[B] = []
    for first, second in pairs:
        _ = left.append(first)
        _ = right.append(second)
    return left, right


def group_by_key[T, K](
    rows: Iterable[T],
    key_func: Callable[[T], K],
) -> dict[K, list[T]]:
    """Callable return drives dict key type; rows preserve element type."""
    grouped: dict[K, list[T]] = {}
    for row in rows:
        key: K = key_func(row)
        _ = grouped.setdefault(key, []).append(row)
    return grouped


def invert_mapping[K, V: Hashable](mapping: Mapping[K, V]) -> dict[V, K]:
    """Swap key/value types when values are hashable."""
    return {value: key for key, value in mapping.items()}


def merge_optional_dicts(
    left: Mapping[str, int],
    right: dict[str, int] | None = None,
) -> dict[str, int]:
    """Optional dict input should narrow before update."""
    merged: dict[str, int] = dict(left)
    if right is not None:
        _ = merged.update(right)
    return merged


def safe_index[T](
    items: Sequence[T],
    index: int,
    default: T | None = None,
) -> T | None:
    """Element type should unify with default type only when needed."""
    try:
        return items[index]
    except IndexError:
        return default


def parse_ints_with_errors(
    values: Iterable[str | int | float],
) -> tuple[list[int], list[tuple[object, str]]]:
    """Exception paths should not poison successful list element type."""
    parsed: list[int] = []
    errors: list[tuple[object, str]] = []
    for value in values:
        try:
            _ = parsed.append(int(value))
        except ValueError as error:
            _ = errors.append((value, str(error)))
    return parsed, errors


def nested_match_payload(
    payload: dict[str, JSONValue],
) -> float | int | str | None:
    """Pattern matching should narrow nested dict/list shapes."""
    match payload:
        case {"kind": "point", "coords": [x, y]}:
            if not (
                isinstance(x, (int, float)) and isinstance(y, (int, float))
            ):
                msg: str = "expected numeric x, y"
                raise TypeError(msg)
            return float(x) + float(y)
        case {"kind": "name", "value": str(name)}:
            return name.title()
        case {"kind": "items", "value": [*items]}:
            return len(items)
        case _:
            return None


def build_typed_dict_like(
    name: str,
    age: int,
    *,
    active: bool = True,
) -> dict[str, int | str | bool]:
    """Repeated literal keys should be candidates for TypedDict inference."""
    return {
        "name": name,
        "age": age,
        "active": active,
    }


def read_known_json_user(blob: str) -> tuple[str, int]:
    """Schema-like validation should refine json.loads object values."""
    data: JSONValue = loads(s=blob)
    if not isinstance(data, dict):
        msg: str = "expected object"
        raise TypeError(msg)
    name: object = data.get("name")
    age: object = data.get("age")
    if not isinstance(name, str):
        msg = "expected string name"
        raise TypeError(msg)
    if not isinstance(age, int):
        msg = "expected integer age"
        raise TypeError(msg)
    return name, age


def callback_pipeline(value: str, *callbacks: Callable[..., object]) -> object:
    """Sequential callable output should feed the next callable input."""
    current: object = value
    for callback in callbacks:
        current = callback(current)
    return current


def make_counter_closure(
    start: float = 0,
) -> Callable[[float], float]:
    """Closure variable mutation should preserve numeric type."""
    total: float = start

    def add(amount: float) -> float:
        """Return add.

        Args:
            amount (float): The amount value passed to the call.

        Returns:
            The computed value of type ``float``.

        """
        nonlocal total
        total += amount
        return total

    return add


def make_registry() -> dict[str, Callable[..., object]]:
    """Nested functions stored in dict should preserve callable returns."""

    def as_upper(value: str) -> str:
        """Return as upper.

        Args:
            value (str): The value value passed to the call.

        Returns:
            The computed value of type ``str``.

        """
        return value.upper()

    def as_length(value: Sized) -> int:
        """Return as length.

        Args:
            value (Sized): The value value passed to the call.

        Returns:
            The computed value of type ``int``.

        """
        return len(value)

    return {
        "upper": as_upper,
        "length": as_length,
    }


def add_logging[**P, R](func: Callable[P, R]) -> Callable[P, R]:
    """Decorator that prints the wrapped callable's name before forwarding.

    Demonstrates the v4 §3 Target 1 pattern: a function-shaped decorator
    that preserves the wrapped callable's full signature through a
    nested ``wrapper`` that forwards both positional and keyword
    argument packs. The ParamSpec promotion pass should rewrite this as
    ``add_logging[**P, R](func: Callable[P, R]) -> Callable[P, R]`` with
    the wrapper typed as ``(*args: P.args, **kwargs: P.kwargs) -> R``.
    """

    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        """Return wrapper.

        Args:
            *args (P.args): The args value passed to the call.
            **kwargs (P.kwargs): The kwargs value passed to the call.

        Returns:
            The computed value of type ``R``.

        """
        aprint(func.__name__)
        return func(*args, **kwargs)

    return wrapper


def trace_method[SelfT, **P, R](
    func: Callable[Concatenate[SelfT, P], R],
) -> Callable[Concatenate[SelfT, P], R]:
    """Method decorator preserving the bound-method signature.

    Demonstrates the v5 §3 Target 2 pattern: a wrapper whose first
    positional parameter is the bound ``self``, followed by the forwarded
    ``*args``/``**kwargs`` pack. The ParamSpec method- decorator
    promotion pass should rewrite this as ``trace_method[SelfT,
    **P, R](func: Callable[Concatenate[SelfT, P], R])`` so the
    bound receiver's type is preserved through ``Concatenate``.
    """

    def wrapper(self: SelfT, *args: P.args, **kwargs: P.kwargs) -> R:
        """Return wrapper.

        Args:
            self: The bound-method receiver.
            *args (P.args): The args value passed to the call.
            **kwargs (P.kwargs): The kwargs value passed to the call.

        Returns:
            The computed value of type ``R``.

        """
        return func(self, *args, **kwargs)

    return wrapper


# =============================================================================
# 25. TypeVarTuple stress fixtures (v4 §4 — inference deferred, fixtures only)
# =============================================================================
# These two functions are the canonical variadic-tuple-pack and variadic-
# callback-pack patterns that future TypeVarTuple inference work must
# distinguish from ordinary homogeneous ``*args``. They are present in the
# demo as stress fixtures: the inference pass does not yet rewrite them, but
# their continued presence (and the basedpyright clean status of the generated
# output) is the regression gate for the upcoming TypeVarTuple bundle.


def rotate_left[T, *Ts](
    items: tuple[T, *Ts],
) -> tuple[*Ts, T]:
    """Rotate a tuple left one position while preserving its element types.

    Demonstrates ``TypeVarTuple`` shape-preservation: the return type
    re-orders the pack so the first element moves to the end while each
    non-first element keeps its precise type. This is the smallest test
    that distinguishes ``TypeVarTuple`` from homogeneous ``tuple[T, ...]``.
    """
    return (*items[1:], items[0])


def call_with_args[*Ts, R](
    callback: Callable[[*Ts], R],
    *args: *Ts,
) -> R:
    """Forward a positional pack to a callback typed by the same pack.

    Demonstrates ``TypeVarTuple`` for callable forwarding: the
    ``*Ts`` pack on both the callback's parameter list and the
    outer ``*args`` ensures the caller cannot pass a positional
    shape the callback cannot accept. Distinct from ``ParamSpec``,
    which forwards a *signature* including keyword arguments.
    """
    return callback(*args)


def sum_values(*values: float) -> float:
    """Sum a homogeneous variadic ``float`` pack.

    Negative ``TypeVarTuple`` fixture: ``*values: float`` is a homogeneous
    pack, so a future ``TypeVarTuple`` inference pass must leave it verbatim
    and NOT promote it to ``*Ts``. v5 §5 requires this distinction; the
    regression gate is in :class:`TestV5TypeVarTupleNegativeFixture`.
    """
    return sum(values)


async def async_fetch_one(
    name: Sized,
    delay: float = 0,
) -> dict[str, Sized | int]:
    """Coroutine result type should survive gather/create_task."""
    await sleep(delay=delay)
    return {"name": name, "size": len(name)}


async def async_fetch_many(
    names: Iterable[Sized],
) -> list[dict[str, Sized | int]]:
    """Return async fetch many.

    Args:
        names (Iterable[Sized]): The names value passed to the call.

    Returns:
        The computed value of type ``list[dict[str, Sized | int]]``.

    """
    tasks: list[Task[dict[str, Sized | int]]] = [
        create_task(coro=async_fetch_one(name=name)) for name in names
    ]
    return await gather(*tasks)


def path_roundtrip(path: str) -> tuple[str, str, Path]:
    """PathLike/string inputs often need pathlib-aware inference."""
    resolved: Path = Path(path).expanduser()
    return resolved.name, resolved.suffix, resolved.parent


def regex_groupdict(text: str) -> dict[str, str | None]:
    """Regex match narrowing should refine groupdict return."""
    match: Match[str] | None = re_match(
        pattern=r"(?P<name>[a-z]+)-(?P<id>\d+)$",
        string=text,
    )
    if match is None:
        return {}
    return match.groupdict()


def bytes_text_boundary(
    data: bytes | str,
    encoding: str = "utf-8",
) -> bytes | str:
    """Bytes/str conversion should not collapse to object."""
    if isinstance(data, bytes):
        return data.decode(encoding)
    return data.encode(encoding)


def variadic_numeric_sum(*values: float, scale: float = 1) -> float:
    """Variadic args plus keyword-only numeric parameter."""
    total: float = 0
    for value in values:
        total += value
    return total * scale


class Plugin(Protocol):
    """Represent Plugin."""

    def run(self, payload: object) -> object:
        """Run the plugin against ``payload``."""
        ...


class EchoPlugin:
    """Represent EchoPlugin."""

    def run(self, payload: object) -> object:
        """Return run.

        Args:
            payload (object): The payload value passed to the call.

        Returns:
            The computed value of type ``object``.

        """
        return payload


class SizePlugin:
    """Represent SizePlugin."""

    def run(self, payload: Sized) -> int:
        """Return run.

        Args:
            payload (Sized): The payload value passed to the call.

        Returns:
            The computed value of type ``int``.

        """
        return len(payload)


def run_plugin(plugin: EchoPlugin | SizePlugin, payload: str) -> object:
    """Structural protocol candidate from repeated .run() calls."""
    return plugin.run(payload)


def stress_smoke_calls() -> dict[
    str,
    dict[object, object]
    | dict[str, object | bool]
    | float
    | int
    | list[object]
    | object
    | tuple[float, float]
    | tuple[list[int], list[tuple[object, str]]]
    | tuple[list[object], list[object]]
    | tuple[object, int, int]
    | tuple[object, object]
    | tuple[str, str, Path]
    | None,
]:
    """Return deterministic outputs for the additional stress section."""
    event_log: object = (
        EventLog()
        .add(name="a")
        .add(name="b", amount=2)
        .add(name="a", amount=3)
    )
    store: KeyValueStore = KeyValueStore()
    previous: object = store.put(key="x", value=1)
    _ = store.put(key="y", value=2)
    counter: FluentCounter = FluentCounter.from_values(values=[1, 2, 3]).add(
        amount=4,
    )
    lazy: LazyValue = LazyValue(raw="  Hello  ")
    descriptor_value: object = DescriptorUser().rename(value="Ada")
    mapping: dict[str, int] = {"a": 1}
    with temporary_mapping_value(
        mapping=mapping,
        key="a",
        value=9,
    ) as old_value:
        temporary_value: int = mapping["a"]
    add: Callable[[float], float] = make_counter_closure(start=10)
    registry: dict[str, Callable[..., object]] = make_registry()
    return {
        "event_log": event_log.summary(),
        "store_previous": previous,
        "store_keys": store.keys_list(),
        "store_values": store.values_list(),
        "counter": counter.total,
        "lazy": lazy.value,
        "descriptor": descriptor_value,
        "temporary": (old_value, temporary_value, mapping["a"]),
        "select": select_first_present(
            primary=None,
            secondary="secondary",
            fallback="fallback",
        ),
        "transpose": transpose_pairs(pairs=[("a", 1), ("b", 2)]),
        "group": group_by_key(rows=["aa", "b"], key_func=len),
        "invert": invert_mapping(mapping={"a": 1, "b": 2}),
        "merge": merge_optional_dicts(left={"a": 1}, right={"b": 2}),
        "safe_index": safe_index(items=[1, 2], index=9, default=-1),
        "parsed": parse_ints_with_errors(values=["1", "x", "3"]),
        "match_point": nested_match_payload(
            payload={"kind": "point", "coords": [1, 2]},
        ),
        "typed_dict_like": build_typed_dict_like(name="Ada", age=37),
        "json_user": read_known_json_user(blob='{"name":"Ada","age":37}'),
        "callback": callback_pipeline(" ada ", str.strip, str.title),
        "closure": (add(5), add(2)),
        "registry": (registry["upper"]("ada"), registry["length"]("ada")),
        "async_many": asyncio_run(main=async_fetch_many(names=["aa", "bbb"])),
        "path": path_roundtrip(path="demo.py"),
        "regex": regex_groupdict(text="abc-123"),
        "boundary_text": bytes_text_boundary(data=b"abc"),
        "boundary_bytes": bytes_text_boundary(data="abc"),
        "variadic": variadic_numeric_sum(1, 2, 3, scale=2),
        "plugin_echo": run_plugin(plugin=EchoPlugin(), payload="x"),
        "plugin_size": run_plugin(plugin=SizePlugin(), payload="abcd"),
    }


# =============================================================================
# 77. Demo entry point — printed when the pipeline auto-runs the file
# =============================================================================


def _demo_main() -> None:
    """Smoke-call a handful of items so the auto-run emits useful output."""
    aprint("google_style ->", google_style(names=["  a ", "b"]))
    aprint("union_via_reassignment ->", union_via_reassignment(flag=True))
    aprint("narrow_via_is_none(None) ->", narrow_via_is_none(value=None))
    aprint("colour_to_hex('red') ->", colour_to_hex(colour="red"))
    aprint("build_user_record ->", build_user_record(name="alice", age=30))
    aprint(
        "Vector3 dot ->",
        Vector3(x=1, y=2, z=3).dot(other=Vector3(x=4, y=5, z=6)),
    )
    aprint("Builder ->", Builder().add(x="a").add(x="b").build())
    aprint("top_words ->", top_words(text="a a b c a b", n=2))
    aprint("yield_in_loop ->", list(yield_in_loop(n=3)))
    aprint(
        "first_long_token ->",
        first_long_token(text="short pretty looong tail"),
    )
    aprint("describe_action ->", describe_action(payload={"kind": "stop"}))
    aprint("parse_user_json ->", parse_user_json(blob='{"name":"x","age":7}'))
    aprint("extract_first_int ->", extract_first_int(text="ab12cd34"))
    aprint("normalise_whitespace ->", normalise_whitespace(text="a  b\tc"))
    aprint("length_doubled ->", length_doubled(text="abc"))
    aprint("temperature_score ->", temperature_score(celsius=25))
    aprint("grade_from_score ->", grade_from_score(score=83))
    aprint("OrderingHeavy ->", OrderingHeavy(items=[1, 2, 3]).public_action())
    aprint("fib(10) ->", fib(n=10))
    aprint("status_priority ->", status_priority(status=Status.RUNNING))
    aprint("HistoryBuffer ->", HistoryBuffer(items=["a", "b"]).count)
    aprint("walrus_filter ->", walrus_filter(items=["  ", "x", "y "]))
    aprint("format_record ->", format_record(name="bob", score=87.5, width=8))
    aprint("CountDown ->", list(CountDown(start=3)))
    aprint("is_str_list ->", join_if_strings(items=["a", "b"]))
    aprint("consume_gate ->", asyncio_run(main=consume_gate(limit=3)))
    aprint("forward_narrow ->", forward_narrow_pipeline(raw="17:42:99"))
    aprint("call_packet_helpers ->", call_packet_helpers())
    aprint("use_closures ->", use_closures())
    aprint("process_status ->", process_status(status="active"))
    aprint("handle_mode ->", handle_mode(mode="inactive"))
    aprint("render_state ->", render_state(state="active"))
    aprint("cached_fib(10) ->", cached_fib(n=10))
    aprint("cached_title ->", cached_title(value="  hello world  "))
    aprint("FormalGreeter ->", FormalGreeter().greet(name="Ada"))
    aprint("CasualGreeter ->", CasualGreeter().greet(name="Ada"))
    aprint("batch_summary ->", batch_summary())
    aprint("render_help_banner ->", repr(render_help_banner()[:30]))
    aprint(
        "render_sql_template ->",
        repr(render_sql_template(table="users")[:30]),
    )
    aprint("render_html_skeleton ->", repr(render_html_skeleton()[:30]))
    aprint(
        "parse_with_doc_types ->",
        parse_with_doc_types(raw="a:b:c", retries=2),
    )
    aprint("call_registry ->", call_registry())
    aprint("physics_step ->", physics_step(velocity=10.0, acceleration=0.5))
    _demo_extras()
    _ = time_sleep(1)


def _demo_extras() -> None:
    """Smoke-call the PEP 695 / async / context-manager sections."""
    aprint("first_of([1,2]) ->", first_of(items=[1, 2]))
    aprint("pair_keys ->", pair_keys(mapping={"a": 1, "b": 2}))
    aprint("normalise_primitive(None) ->", normalise_primitive(value=None))
    aprint("join_string_list ->", join_string_list(parts=["a", "b"]))
    aprint("collect_async(3) ->", asyncio_run(main=collect_async(limit=3)))
    with Transaction(label="demo") as txn:
        aprint("Transaction entered ->", txn.entered)
    aprint("stress_smoke_calls ->", stress_smoke_calls())


if __name__ == "__main__":
    _demo_main()
