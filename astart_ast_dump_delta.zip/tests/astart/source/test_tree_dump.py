"""Regression tests for the custom AST JSON exporter."""

from __future__ import annotations

from json import loads
from pathlib import Path

from astart.source.tree_dump import dump_file


def test_dump_file_preserves_custom_nodes_and_tokens(tmp_path: Path) -> None:
    """Export comments, docstrings, executable nodes, and lexical tokens.

    Args:
        tmp_path (Path): Isolated pytest temporary directory.

    """
    source: Path = tmp_path / "example.py"
    output: Path = tmp_path / "nested" / "example.json"
    source.write_text(
        data='#!/usr/bin/env python3\n# comment\ndef f(x: int) -> int:\n'
        '    """Return x.\n\n    Args:\n        x (int): Value.\n\n'
        '    Returns:\n        int: Value.\n    """\n    return x\n',
        encoding="utf-8",
    )
    dump_file(source=source, output=output)
    result: dict[str, object] = loads(output.read_text(encoding="utf-8"))
    assert result["format"] == "astart-custom-ast-v1"
    assert result["token_stream"]
    assert "comment" in str(result["tree"])
    assert "Docstring" in str(result["tree"])
    assert "token_info" in str(result["tree"])
